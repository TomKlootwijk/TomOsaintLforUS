import math
import unittest
from engine.core import *


class GrammarTests(unittest.TestCase):
    def test_exact_generations(self):
        expected = ["0", "1", "01", "101", "01101", "10101101"]
        for depth, word in enumerate(expected):
            self.assertEqual("".join(map(str, iter_word(depth))), word)

    def test_stream_equals_parallel_rewriting(self):
        word = "0"
        for depth in range(14):
            self.assertEqual("".join(map(str, iter_word(depth))), word)
            word = rewrite_once(word)

    def test_counts(self):
        for depth in range(15):
            word = list(iter_word(depth))
            self.assertEqual(symbol_counts(depth), (word.count(0), word.count(1)))

    def test_ratio_converges(self):
        zero, one = symbol_counts(30)
        self.assertAlmostEqual(zero / one, PHI, places=10)

    def test_bounded_prefix(self):
        self.assertEqual(len(list(iter_word(100, limit=17))), 17)
        self.assertEqual(list(iter_word(100, limit=0)), [])

    def test_budget_rejection(self):
        with self.assertRaises(ValueError):
            list(iter_word(100))

    def test_bad_grammar_inputs(self):
        for depth in (-1, 2.5, True, 513):
            with self.assertRaises(ValueError):
                symbol_counts(depth)
        with self.assertRaises(ValueError):
            symbol_counts(2, "012")

    def test_bit_roundtrip(self):
        bits = list(iter_word(10))
        packed, size = pack_bits(bits)
        self.assertEqual(unpack_bits(packed, size), bits)
        self.assertEqual(len(packed), (size + 7) // 8)

    def test_bit_padding_and_invalid_input(self):
        packed, size = pack_bits([1, 0, 1])
        self.assertEqual(packed, bytes([0b10100000]))
        self.assertEqual(size, 3)
        with self.assertRaises(ValueError):
            pack_bits([1, 2])
        with self.assertRaises(ValueError):
            unpack_bits(b"\x00", 9)


class CoordinatesTests(unittest.TestCase):
    def test_pitch_roundtrip(self):
        for frequency in (55, 220, 440, 880, 1760):
            self.assertAlmostEqual(decode_pitch(encode_pitch(frequency)), frequency, places=8)

    def test_octave_is_additive_log_coordinate(self):
        self.assertAlmostEqual(encode_pitch(880) - encode_pitch(440), 1)

    def test_invalid_pitch(self):
        for frequency in (0, -1, math.inf, math.nan):
            with self.assertRaises(ValueError):
                encode_pitch(frequency)
        with self.assertRaises(ValueError):
            decode_pitch(2000)

    def test_spatial_log_polar(self):
        log_radius, angle = log_polar(0, 2)
        self.assertAlmostEqual(log_radius, math.log(2))
        self.assertAlmostEqual(angle, math.pi / 2)

    def test_log_polar_origin_is_undefined(self):
        with self.assertRaises(ValueError):
            log_polar(0, 0)

    def test_phase_wrap(self):
        self.assertAlmostEqual(advance_phase(0.9, 2, 10), 0.1)


class FieldTests(unittest.TestCase):
    def test_sphere_distance(self):
        self.assertEqual(sphere_sdf((3, 0, 0), 2), 1)
        self.assertEqual(sphere_sdf((0, 0, 0), 2), -2)

    def test_blend_symmetry(self):
        self.assertAlmostEqual(polynomial_smin(0.1, 0.2, 1), polynomial_smin(0.2, 0.1, 1))

    def test_blend_outside_support(self):
        self.assertEqual(polynomial_smin(-2, 2, 0.5), -2)

    def test_blend_moves_original_zero(self):
        self.assertAlmostEqual(polynomial_smin(0, 0, 0.4), -0.1)

    def test_blend_requires_positive_width(self):
        with self.assertRaises(ValueError):
            polynomial_smin(0, 0, 0)

    def test_cone_shared_zero_not_shared_values(self):
        self.assertEqual(sound_cone_levelset((3, 0, 0), 3), 0)
        self.assertEqual(acoustic_interval((3, 0, 0), 3), 0)
        self.assertEqual(sound_cone_levelset((4, 0, 0), 3), 1)
        self.assertEqual(acoustic_interval((4, 0, 0), 3), 7)

    def test_future_cone(self):
        with self.assertRaises(ValueError):
            sound_cone_levelset((1, 0, 0), -1)


class TopologyTests(unittest.TestCase):
    def test_glide_seam(self):
        p, q = klein_project(0.2, 0.3), klein_project(1.2, -0.3)
        self.assertAlmostEqual(p.u, q.u)
        self.assertAlmostEqual(p.v, q.v)
        self.assertEqual(p.orientation, -q.orientation)

    def test_vertical_period(self):
        p, q = klein_project(0.2, 0.3), klein_project(0.2, 1.3)
        self.assertAlmostEqual(p.v, q.v)

    def test_two_horizontal_wraps_restore_orientation(self):
        self.assertEqual(klein_project(2.2, 0.3).orientation, 1)
        self.assertAlmostEqual(klein_project(2.2, 0.3).v, 0.3)

    def test_negative_wrap(self):
        p = klein_project(-0.2, 0.3)
        self.assertAlmostEqual(p.u, 0.8)
        self.assertAlmostEqual(p.v, 0.7)
        self.assertEqual(p.orientation, -1)

    def test_scalar_has_no_forced_pressure_inversion(self):
        self.assertAlmostEqual(klein_scalar(0.2, 0.3), klein_scalar(1.2, -0.3))
        self.assertAlmostEqual(klein_scalar(0.2, 0.3), klein_scalar(0.2, 1.3))

    def test_trace_determinism(self):
        self.assertEqual(list(trace_word(iter_word(10))), list(trace_word(iter_word(10))))

    def test_rotations_do_not_advance_grammar_time(self):
        trace = list(trace_word([0, 1, 1, 0]))
        self.assertAlmostEqual(trace[0].grammar_time, trace[2].grammar_time)
        self.assertGreater(trace[3].grammar_time, trace[2].grammar_time)

    def test_rotation_does_not_create_a_branch(self):
        trace = list(trace_word([1, 1]))
        self.assertTrue(all(e.lift_u == 0 and e.lift_v == 0 for e in trace))


class QuantizerTests(unittest.TestCase):
    def test_zero_input(self):
        self.assertEqual([b for b, _ in sigma_delta([0] * 6)], [1, 0, 1, 0, 1, 0])

    def test_dc_tracking(self):
        samples = [0.25] * 4096
        result = list(sigma_delta(samples))
        self.assertAlmostEqual(sum(2*b - 1 for b, _ in result) / len(result), 0.25)

    def test_error_state_and_mean_bound(self):
        samples = [0.8 * math.sin(n * 0.05) for n in range(10000)]
        result = list(sigma_delta(samples))
        self.assertLessEqual(max(abs(e) for _, e in result), 1 + 1e-12)
        tracking = abs(sum(2*b - 1 for b, _ in result) - sum(samples)) / len(samples)
        self.assertLessEqual(tracking, 1 / len(samples) + 1e-12)

    def test_invalid_quantizer_amplitude(self):
        for bad in (1.1, -1.1, math.nan):
            with self.assertRaises(ValueError):
                list(sigma_delta([bad]))

    def test_grammar_bits_are_not_a_zero_mean_audio_code(self):
        word = list(iter_word(20))
        bipolar_mean = sum(2*b - 1 for b in word) / len(word)
        self.assertGreater(bipolar_mean, 0.2)
        self.assertLess(bipolar_mean, 0.3)


if __name__ == "__main__":
    unittest.main()

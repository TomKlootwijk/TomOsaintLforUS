#!/usr/bin/env python3
"""Verify the delivered files against SHA256SUMS.json without modifying them.

This establishes consistency with a local manifest, not identity, ownership,
authenticity, physical performance or a trusted creation time.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1],
                        help="extracted package root (defaults to this script's parent package)")
    parser.add_argument("--strict", action="store_true",
                        help="also fail for unexpected files, ignoring Python bytecode caches")
    args = parser.parse_args()
    root = args.root.resolve()
    manifest_path = root / "SHA256SUMS.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("algorithm") != "SHA256" or not isinstance(manifest.get("files"), list):
            raise ValueError("expected a SHA256 manifest with a files array")
        expected: set[str] = set()
        failures: list[str] = []
        for entry in manifest["files"]:
            name = entry.get("path")
            if not isinstance(name, str) or "\\" in name:
                raise ValueError("invalid manifest path")
            relative = PurePosixPath(name)
            if relative.is_absolute() or ".." in relative.parts or name in ("", "."):
                raise ValueError(f"unsafe manifest path: {name!r}")
            if name in expected or name == "SHA256SUMS.json":
                raise ValueError(f"duplicate or self-referential path: {name!r}")
            expected.add(name)
            expected_hash = entry.get("sha256", "")
            if not isinstance(expected_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
                raise ValueError(f"invalid digest for {name!r}")
            expected_size = entry.get("bytes")
            if isinstance(expected_size, bool) or not isinstance(expected_size, int) or expected_size < 0:
                raise ValueError(f"invalid byte count for {name!r}")
            candidate = root.joinpath(*relative.parts)
            if candidate.is_symlink() or any(p.is_symlink() for p in candidate.parents if p != root):
                raise ValueError(f"symlink in manifest target: {name!r}")
            candidate.resolve().relative_to(root)
            if not candidate.is_file():
                failures.append(f"MISSING: {name}")
                continue
            if candidate.stat().st_size != expected_size:
                failures.append(f"SIZE MISMATCH: {name}")
            elif sha256_file(candidate) != expected_hash:
                failures.append(f"HASH MISMATCH: {name}")
        actual = {
            p.relative_to(root).as_posix() for p in root.rglob("*")
            if p.is_file() and "__pycache__" not in p.parts and p.suffix not in (".pyc", ".pyo")
        }
        extra = sorted(actual - expected - {"SHA256SUMS.json"})
        if args.strict:
            failures.extend(f"UNEXPECTED: {name}" for name in extra)
        if failures:
            print("\n".join(failures), file=sys.stderr)
            print(f"FAILED: {len(failures)} integrity issue(s).", file=sys.stderr)
            return 1
        print(f"OK: {len(expected)} delivered files match their SHA-256 hashes and sizes.")
        if extra:
            print(f"Note: {len(extra)} additional file(s) not covered; use --strict to report them.")
        print("Manifest consistency is not authentication or physical validation.")
        return 0
    except (OSError, ValueError, TypeError, AttributeError) as exc:
        print(f"Verification error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

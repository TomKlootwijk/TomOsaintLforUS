# Kernel profile P0 — executable contract

## Source boundary

The corpus in `Tone.pdf`, pages 21–22, supplies the binary instruction framing
and the rewrite productions `0 -> 1` and `1 -> 01`. Its page 14 supplies the
polynomial blend. The companion `Pasted markdown(9).md`, sections III–IV,
restates those elements. These originals remain in the parent corpus package,
not in this kernel-only archive.

The following numerical interpretation was introduced by the previously
delivered formalization. It is retained here without changing the code. The
source does not determine a unique seed, numerical chart, branch implementation,
turn angle, clock, or complete physical input/output mapping.

## Grammar

`PRODUCTIONS = {"0": "1", "1": "01"}`. The default axiom is `"0"`.
Rewriting is simultaneous, and production order is preserved. Generations
0 through 5 are:

```text
0
1
01
101
01101
10101101
```

The counts evolve as `(zeros, ones) -> (ones, zeros + ones)`.
`symbol_counts` computes integer counts without materializing the word.
`iter_word` performs depth-first expansion in left-to-right output order.
Its `limit` selects a prefix of the requested finite generation, not an
assumed common prefix of all generations. Maximum depth is 512. The default
emission budget is 1,000,000 symbols. Materializing a full word still requires
storage proportional to its length.

## Interpreter and topology

The initial lifted state is `(u, v, heading, grammar_time) = (0, 0, 0, 0)`.
`PHI = (sqrt(5)-1)/2` follows the corpus's reciprocal-golden-ratio convention.
The proposed turn is `2*pi*(1-PHI)` radians.

Instruction `0` moves by `step*(cos(heading), sin(heading))` and advances
`grammar_time` by `time_step`. Defaults are `step=0.125` in dimensionless
chart units and `time_step=0.01`. Instruction `1` rotates the heading modulo
`2*pi` without moving, advancing grammar time, or creating a branch.

The chart identifications are `(u+1,v) ~ (u,-v)` and `(u,v+1) ~ (u,v)`.
For `n=floor(u)`, the returned chart coordinates are
`u'=u-n`, `v'=((-1)**n*v) mod 1`, with orientation label `(-1)**n`.
The lifted heading remains available; the local heading reflects its vertical
component with chart parity. Orientation is not interpreted as pressure sign.
The demo scalar is `0.5*(cos(2*pi*u')+cos(2*pi*v'))`.

Each `TraceEvent` records the index, instruction, lifted position, heading,
grammar time, chart position, orientation, local heading, and scalar after
the instruction. Audio sample time is a separate clock.

## Coordinate and field helpers

Pitch uses `rho=log2(f/f_ref)` and `f=f_ref*2**rho`, with a default reference
of 440 Hz. The spatial log-polar helper instead uses natural log radius and
an angle in radians; it rejects the coordinate origin.

The sphere function returns `norm(point-center)-radius`. The future sound-front
function returns `norm(point)-speed*(time-start_time)`, while the quadratic
interval returns `norm(point)**2-speed**2*(time-start_time)**2`. The interval
has squared-length units; it is not the same quantity as a signed distance.

For positive `k`, the polynomial blend implements
`min(a,b)-max(k-abs(a-b),0)**2/(4*k)`. It operates on supplied scalar fields;
it is neither a pressure mixer nor a guarantee of exact signed distances.

## Offline output adapter

The demo maps the scalar to `rho=0.5*scalar` and reschedules the 233 depth-12
events across 16,000 samples at 16 kHz. It creates an enveloped, two-harmonic
floating-point reference signal. The WAV stores that reference as 16-bit
mono PCM. It is not a reconstruction of the one-bit quantizer output.

For reference input `x` in `[-1,1]`, the separate quantizer starts at error
`e=0`. Each step computes `v=e+x`, `bit=1 if v>=0 else 0`, and
`e=v-(2*bit-1)`. There is no automatic oversampling, dither, or reconstruction
filter. The generated bit files have no hardware timing or driver interface.

Packed bits are most-significant-bit first. The final byte is zero-padded.
The logical bit count must accompany the bytes; the demo records it in
`demo_summary.json`. Padding bits are not instructions or extra samples.

## Validation boundary

The included 35 tests check the declared grammar, counts, budgets, packing,
coordinate helpers, elementary fields, quotient-chart behavior, trace
semantics, and algebraic quantizer properties. Passing these tests does not
validate the source's proposed physical mechanisms or every possible input.
See `VALIDATION.json` for the actual run and environment.

"""Generate bounded OFFLINE examples, without playback or hardware access.
Run from the package root: python -m engine.demo --output examples
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import platform
import struct
import wave
from dataclasses import asdict
from pathlib import Path
from .core import (PHI, iter_word, symbol_counts, trace_word, decode_pitch,
                   advance_phase, sigma_delta, pack_bits, polynomial_smin,
                   sound_cone_levelset, acoustic_interval)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("examples"))
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    depth = 12
    bits = list(iter_word(depth))
    events = list(trace_word(bits))
    write_csv(out / "trajectory.csv", [asdict(event) for event in events])
    payload, length = pack_bits(bits)
    (out / "grammar_bits.bin").write_bytes(payload)
    (out / "grammar_word.txt").write_text("".join(map(str, bits)) + "\n", encoding="utf-8")
    write_csv(out / "grammar_growth.csv", [
        {"depth": d, "zeros": symbol_counts(d)[0], "ones": symbol_counts(d)[1],
         "length": sum(symbol_counts(d))} for d in range(21)
    ])
    write_csv(out / "pitch_map.csv", [
        {"rho_octaves": rho, "frequency_hz": decode_pitch(rho)}
        for rho in (-2, -1, -0.5, 0, 0.5, 1, 2)
    ])
    write_csv(out / "field_checks.csv", [
        {"case": "smin_original_zero_shift", "value": polynomial_smin(0, 0, 0.4)},
        {"case": "sound_front_spatial_distance", "value": sound_cone_levelset((3, 0, 0), 3)},
        {"case": "sound_front_quadratic_interval", "value": acoustic_interval((3, 0, 0), 3)},
    ])
    # The WAV contains the MULTIBIT reference waveform, not a reconstructed
    # one-bit stream. These are separate adapters and intentionally labelled.
    sample_rate, count = 16000, 16000
    phase, samples = 0.0, []
    preview = []
    for n in range(count):
        event = events[min(len(events) - 1, n * len(events) // count)]
        rho = 0.5 * event.scalar
        frequency = decode_pitch(rho)
        phase = advance_phase(phase, frequency, sample_rate)
        morph = 0.5 * (event.scalar + 1.0)
        # Raised-cosine start/end fade; digital normalization is NOT an SPL limit.
        envelope = math.sin(math.pi * n / (count - 1)) ** 2
        value = 0.1 * envelope * ((1 - 0.25 * morph) * math.sin(math.tau * phase)
                                 + 0.25 * morph * math.sin(2 * math.tau * phase))
        samples.append(value)
        if n < 512:
            preview.append({"sample": n, "sample_time_s": n / sample_rate,
                            "rho_octaves": rho, "frequency_hz": frequency,
                            "reference_amplitude": value})
    with wave.open(str(out / "reference_waveform.wav"), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(b"".join(struct.pack("<h", round(x * 32767)) for x in samples))
    # First-order bitstream at the SAME 16 kHz clock; no claim of audio quality
    # or adequate oversampling. Only algebraic invariants are demonstrated.
    sd = list(sigma_delta(samples))
    sd_bytes, sd_count = pack_bits(bit for bit, _ in sd)
    (out / "quantizer_bits.bin").write_bytes(sd_bytes)
    for row, (bit, error) in zip(preview, sd):
        row["quantizer_bit"] = bit
        row["quantizer_error_state"] = error
    write_csv(out / "signal_preview.csv", preview)
    summary = {
        "status": "offline proposal demonstrator; not a physical validation",
        "python": platform.python_version(), "axiom": "0", "depth": depth,
        "productions": {"0": "1", "1": "01"},
        "grammar_bit_count": length, "grammar_packed_bytes": len(payload),
        "grammar_zero_count": bits.count(0), "grammar_one_count": bits.count(1),
        "grammar_zero_one_ratio": bits.count(0) / bits.count(1),
        "phi_reciprocal": PHI,
        "negative_orientation_events": sum(e.orientation < 0 for e in events),
        "reference_waveform_sample_rate_hz": sample_rate,
        "reference_waveform_samples": count,
        "reference_waveform_peak": max(abs(x) for x in samples),
        "quantizer_bit_count": sd_count,
        "quantizer_max_abs_error_state": max(abs(e) for _, e in sd),
        "mean_tracking_error": abs(sum(2*b-1 for b, _ in sd) - sum(samples)) / count,
        "mean_tracking_bound": 1.0 / count,
        "bit_order": "MSB-first; pad final byte with zeroes; use logical bit_count",
        "not_implemented": ["branching", "lookup texture backend", "float-free arithmetic",
                            "caustic amplitude solver", "physical wave propagation solver",
                            "Klein-bottle signed-distance oracle", "hardware driver",
                            "dither", "clock-jitter model", "analog reconstruction filter"]
    }
    (out / "demo_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

"""Offline research demonstrator accompanying Tom Klootwijk's corpus dossier.

This package is an explicit implementation proposal, not recovered author code.
It has no hardware-control, network, acoustic-focusing or power-output interface.
"""
__version__ = "0.1.0"

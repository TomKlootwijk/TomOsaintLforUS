"""Typed, bounded components for the corpus formalization (Python 3.10+).

The corpus supplies the productions 0->1 and 1->01 and the polynomial smin.
The seed, execution semantics, chart, units and output adapter below are NEW,
explicit proposal choices. Floating point is used for clarity, so this is not
an implementation of the corpus's proposed all-one-bit / float-free machine.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections.abc import Iterable, Iterator
import math

PHI = (math.sqrt(5.0) - 1.0) / 2.0   # reciprocal golden ratio, corpus convention
GOLDEN_TURN = math.tau * (1.0 - PHI)  # proposal, not specified by corpus
PRODUCTIONS = {"0": "1", "1": "01"}
MAX_DEPTH = 512
DEFAULT_BUDGET = 1_000_000


def _finite(value: float, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number, not bool")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def _integer(value: int, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _word(word: str) -> str:
    if not isinstance(word, str) or not word or any(c not in "01" for c in word):
        raise ValueError("axiom/word must be a nonempty binary string")
    return word


def symbol_counts(depth: int, axiom: str = "0") -> tuple[int, int]:
    """Return exact (zero_count, one_count) without expanding the word."""
    _integer(depth, "depth")
    if depth > MAX_DEPTH:
        raise ValueError(f"depth must not exceed {MAX_DEPTH}")
    _word(axiom)
    zero, one = axiom.count("0"), axiom.count("1")
    for _ in range(depth):
        zero, one = one, zero + one
    return zero, one


def rewrite_once(word: str) -> str:
    _word(word)
    if sum(len(PRODUCTIONS[c]) for c in word) > DEFAULT_BUDGET:
        raise ValueError("expanded word exceeds materialization budget")
    return "".join(PRODUCTIONS[c] for c in word)


def iter_word(depth: int, axiom: str = "0", *, limit: int | None = None,
              budget: int = DEFAULT_BUDGET) -> Iterator[int]:
    """Stream a finite generation in exact left-to-right production order.

    A limit is a prefix of THIS finite generation. Successive generations are
    not assumed to be nested prefixes. Auxiliary stack O(depth + len(axiom));
    emitting the full generation still costs O(number of emitted symbols).
    """
    expected = sum(symbol_counts(depth, axiom))
    _integer(budget, "budget", 1)
    if limit is not None:
        _integer(limit, "limit")
    required = expected if limit is None else min(expected, limit)
    if required > budget:
        raise ValueError("requested output exceeds budget; set a smaller limit")
    if required == 0:
        return
    stack = [(symbol, depth) for symbol in reversed(axiom)]
    emitted = 0
    while stack and emitted < required:
        symbol, remaining = stack.pop()
        if remaining == 0:
            yield int(symbol)
            emitted += 1
        else:
            for child in reversed(PRODUCTIONS[symbol]):
                stack.append((child, remaining - 1))


def encode_pitch(frequency: float, reference: float = 440.0) -> float:
    f, ref = _finite(frequency, "frequency"), _finite(reference, "reference")
    if f <= 0 or ref <= 0:
        raise ValueError("frequency and reference must be positive")
    return math.log2(f) - math.log2(ref)


def decode_pitch(rho: float, reference: float = 440.0) -> float:
    rho, ref = _finite(rho, "rho"), _finite(reference, "reference")
    if ref <= 0:
        raise ValueError("reference must be positive")
    try:
        result = ref * (2.0 ** rho)
    except OverflowError as exc:
        raise ValueError("pitch is outside floating-point range") from exc
    if not math.isfinite(result) or result <= 0:
        raise ValueError("pitch is outside floating-point range")
    return result


def log_polar(x: float, y: float, reference_radius: float = 1.0) -> tuple[float, float]:
    """Spatial log radius (natural log) and angle; distinct from pitch rho."""
    x, y = _finite(x, "x"), _finite(y, "y")
    r0 = _finite(reference_radius, "reference_radius")
    radius = math.hypot(x, y)
    if r0 <= 0 or radius == 0 or not math.isfinite(radius):
        raise ValueError("log-polar chart requires finite radius > 0 and r0 > 0")
    return math.log(radius) - math.log(r0), math.atan2(y, x) % math.tau


def advance_phase(phase: float, frequency: float, sample_rate: float) -> float:
    phase = _finite(phase, "phase")
    frequency = _finite(frequency, "frequency")
    sample_rate = _finite(sample_rate, "sample_rate")
    if not 0 <= phase < 1 or frequency < 0 or sample_rate <= 0:
        raise ValueError("require phase in [0,1), frequency >= 0 and sample_rate > 0")
    result = phase + frequency / sample_rate
    if not math.isfinite(result):
        raise ValueError("phase increment overflow")
    return result % 1.0


def polynomial_smin(a: float, b: float, k: float) -> float:
    """The corpus polynomial blend. NOT a pressure mixer or exact-SDF guarantee."""
    a, b, k = _finite(a, "a"), _finite(b, "b"), _finite(k, "k")
    if k <= 0:
        raise ValueError("k must be positive and have the same units as a and b")
    h = max(1.0 - abs(a - b) / k, 0.0)
    return min(a, b) - (0.25 * k) * h * h


def _point(point: tuple[float, float, float]) -> tuple[float, float, float]:
    if len(point) != 3:
        raise ValueError("point must have exactly three coordinates")
    return tuple(_finite(v, "coordinate") for v in point)  # type: ignore[return-value]


def sphere_sdf(point: tuple[float, float, float], radius: float,
               center: tuple[float, float, float] = (0.0, 0.0, 0.0)) -> float:
    p, c = _point(point), _point(center)
    radius = _finite(radius, "radius")
    if radius < 0:
        raise ValueError("radius must be nonnegative")
    value = math.dist(p, c) - radius
    return _finite(value, "distance result")


def sound_cone_levelset(point: tuple[float, float, float], time: float,
                        speed: float = 1.0, start_time: float = 0.0) -> float:
    """Distance to a spherical front at a fixed future time; not a 4-D SDF."""
    time, start = _finite(time, "time"), _finite(start_time, "start_time")
    speed = _finite(speed, "speed")
    if time < start or speed <= 0:
        raise ValueError("require time >= start_time and speed > 0")
    return sphere_sdf(point, _finite(speed * (time - start), "radius"))


def acoustic_interval(point: tuple[float, float, float], time: float,
                      speed: float = 1.0, start_time: float = 0.0) -> float:
    """q = ||x||^2 - c_s^2 (t-t0)^2; squared-length units, not distance."""
    p = _point(point)
    time, start = _finite(time, "time"), _finite(start_time, "start_time")
    speed = _finite(speed, "speed")
    if speed <= 0:
        raise ValueError("speed must be positive")
    q = math.fsum(v * v for v in p) - (speed * (time - start)) ** 2
    return _finite(q, "interval result")


@dataclass(frozen=True)
class ChartPoint:
    u: float
    v: float
    orientation: int


def klein_project(u: float, v: float) -> ChartPoint:
    """Project a lift onto (u+1,v)~(u,-v), (u,v+1)~(u,v).

    orientation is a chart/lift label, NOT an acoustic pressure sign. The
    projection intentionally forgets winding except for this parity label.
    """
    u, v = _finite(u, "u"), _finite(v, "v")
    crossing = math.floor(u)
    orientation = -1 if crossing % 2 else 1
    return ChartPoint(u - crossing, (orientation * v) % 1.0, orientation)


def klein_scalar(u: float, v: float) -> float:
    """An ordinary scalar invariant under both declared deck transformations."""
    u, v = _finite(u, "u"), _finite(v, "v")
    return 0.5 * (math.cos(math.tau * u) + math.cos(math.tau * v))


@dataclass(frozen=True)
class TraceEvent:
    index: int
    symbol: int
    lift_u: float
    lift_v: float
    heading: float
    grammar_time: float
    chart_u: float
    chart_v: float
    orientation: int
    local_heading: float
    scalar: float


def trace_word(symbols: Iterable[int], *, step: float = 0.125,
               time_step: float = 0.01, turn: float = GOLDEN_TURN,
               max_events: int = DEFAULT_BUDGET) -> Iterator[TraceEvent]:
    """Proposal profile: 0 moves/ticks; 1 rotates instantaneously; no branching.

    The universal-cover heading is preserved; the local v component reverses
    when the chart parity reverses. Sample-clock time is a separate concept.
    """
    step, dt, turn = _finite(step, "step"), _finite(time_step, "time_step"), _finite(turn, "turn")
    _integer(max_events, "max_events", 1)
    if step <= 0 or dt <= 0:
        raise ValueError("step and time_step must be positive")
    u = v = heading = time = 0.0
    for index, symbol in enumerate(symbols):
        if index >= max_events:
            raise ValueError("event budget exceeded")
        if isinstance(symbol, bool) or symbol not in (0, 1):
            raise ValueError("instruction symbols must be integers 0 or 1")
        if not isinstance(symbol, int):
            raise ValueError("instruction symbols must be integers 0 or 1")
        if symbol == 0:
            u += step * math.cos(heading)
            v += step * math.sin(heading)
            time += dt
        else:
            heading = (heading + turn) % math.tau
        chart = klein_project(u, v)
        yield TraceEvent(index, symbol, u, v, heading, time, chart.u, chart.v,
                         chart.orientation, (chart.orientation * heading) % math.tau,
                         klein_scalar(chart.u, chart.v))


def sigma_delta(samples: Iterable[float], *, max_samples: int = DEFAULT_BUDGET
                ) -> Iterator[tuple[int, float]]:
    """Offline first-order error-feedback example: returns (bit, error state).

    Input must be in [-1,1]. No dither, clock-jitter simulation, analog filter,
    power-stage model or hardware interface is present. Each input is already
    a sample at the chosen BITSTREAM clock, not automatically oversampled.
    """
    _integer(max_samples, "max_samples", 1)
    error = 0.0
    for index, sample in enumerate(samples):
        if index >= max_samples:
            raise ValueError("sample budget exceeded")
        sample = _finite(sample, "sample")
        if not -1.0 <= sample <= 1.0:
            raise ValueError("sigma-delta input must lie in [-1,1]")
        value = error + sample
        bit = 1 if value >= 0 else 0
        error = value - (2 * bit - 1)
        yield bit, error


def pack_bits(bits: Iterable[int], *, max_bits: int = DEFAULT_BUDGET) -> tuple[bytes, int]:
    """MSB first, zero padding in final byte; returns data and logical bit count."""
    _integer(max_bits, "max_bits", 1)
    output = bytearray()
    byte = count = 0
    for bit in bits:
        if count >= max_bits:
            raise ValueError("bit budget exceeded")
        if isinstance(bit, bool) or not isinstance(bit, int) or bit not in (0, 1):
            raise ValueError("bit must be integer 0 or 1")
        byte = (byte << 1) | bit
        count += 1
        if count % 8 == 0:
            output.append(byte)
            byte = 0
    if count % 8:
        output.append(byte << (8 - count % 8))
    return bytes(output), count


def unpack_bits(data: bytes, bit_count: int) -> list[int]:
    _integer(bit_count, "bit_count")
    if bit_count > len(data) * 8:
        raise ValueError("bit_count exceeds byte capacity")
    return [(data[i // 8] >> (7 - i % 8)) & 1 for i in range(bit_count)]

# Attribution, provenance, and licensing status

Prepared for **Tom Klootwijk** as a kernel-only delivery of the software
reference implementation accompanying his requested corpus formalization.

The corpus and organizing concept are attributed to Tom Klootwijk as requested.
The reference code and implementation choices were prepared with AI assistance
for the preceding edition. The source exports include AI/search-generated
commentary; passage-level authorship was not independently established.

The executable modules and original test suite in this archive are unchanged
from that preceding package. Packaging documentation and validation records
were prepared for this delivery. `PROVENANCE.json` records the source archive
and the exact retained files. The original corpus files and the full report
are not duplicated here.

This note does not select a new open-source license, certify novelty or
priority, establish ownership of mathematical methods, or grant third-party
rights. No identity verification, legal registration, patent filing, or
physical validation was performed. No warranty of production suitability or
physical performance is asserted.

This kernel-only package retains the attribution name; it does not repeat the
personal identifier and date supplied for the dossier. Its metadata refers to
the preceding package by filename and cryptographic digest.

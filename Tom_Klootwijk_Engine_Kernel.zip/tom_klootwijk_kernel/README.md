# Tom Klootwijk — Engine Kernel

**Standalone reference kernel, version 0.1.0 · Profile P0**

This archive isolates the executable software core from the accompanying
*Corpus and Engine* formalization. `engine/core.py`, the demonstration driver,
and the 35-test suite are copied **without modification** from the previously
delivered package. No full report, original dialogue exports, or external
libraries are required to run it.

## Run

Requires **Python 3.10 or newer**, using only the standard library. Extract the
ZIP, open a terminal in the `tom_klootwijk_kernel` directory, and run:

```sh
python -m unittest discover -s tests -v
python -m engine.demo --output run_output
python tools/verify_package.py
```

Use `python3` instead of `python` when that is the Python 3 command on your
system. No installation, network connection, credentials, or hardware access
is needed. The demo writes files; it does not play audio.

The `examples/` directory contains a newly generated reference run. Use a
different output directory, as shown above, to keep those delivered records
unchanged. For a fresh extraction, `python tools/verify_package.py --strict`
also detects unexpected files. After generating `run_output/`, the normal
(non-strict) check still verifies every delivered file.

## Kernel components

| Component | Entry points in `engine/core.py` |
|---|---|
| Exact binary grammar `0 -> 1`, `1 -> 01` | `rewrite_once`, `symbol_counts`, `iter_word` |
| Bounded grammar execution and chart trace | `trace_word`, `TraceEvent` |
| Klein quotient chart and invariant scalar | `klein_project`, `klein_scalar`, `ChartPoint` |
| Pitch, log-polar coordinates, phase | `encode_pitch`, `decode_pitch`, `log_polar`, `advance_phase` |
| Analytic sphere and cone fields, blend | `sphere_sdf`, `sound_cone_levelset`, `acoustic_interval`, `polynomial_smin` |
| Separate first-order one-bit quantizer | `sigma_delta` |
| MSB-first binary storage | `pack_bits`, `unpack_bits` |

The demo connects a grammar trace to a proposed pitch-control adapter, emits
CSV diagnostics and packed bit files, and writes a one-second PCM reference
WAV. Grammar instructions and quantizer samples are distinct streams.

## Import directly

Run this from the extracted directory:

```python
from engine.core import iter_word, trace_word, pack_bits, unpack_bits

# This is finite generation 12, not a prefix shared by all generations.
bits = list(iter_word(12))
assert len(bits) == 233

for event in trace_word(bits):
    # Application-specific processing belongs here.
    pass

payload, logical_bit_count = pack_bits(bits)
assert unpack_bits(payload, logical_bit_count) == bits
```

For a bounded prefix of a much larger finite generation:

```python
from engine.core import iter_word
prefix = list(iter_word(100, limit=64))
assert len(prefix) == 64
```

## What is defined, and what is not

This is the **reference implementation proposed in the formalization**, not
recovered original author code or a validated realization of every physical
claim in the corpus. The production rules and polynomial blend are drawn from
the corpus. The seed, numerical chart, turn angle, execution state, and output
adapter are explicit proposal choices recorded in `KERNEL_SPEC.md` and
`data/engine_profile.json`.

The core uses floating-point coordinates and is rotation-only: it does not
implement a branch stack. It has no propagation/caustics solver, global
Klein-bottle signed-distance oracle, dither or clock-jitter model, analog
reconstruction, GPU lookup texture, or hardware driver. It does not establish
alias-free output, physical energy recirculation, or acoustic focusing.

`data/engine_profile.json` describes this implementation; the demo does not
load it as a configuration file. Change the Python API arguments or driver
explicitly to change execution.

## Package records

`VALIDATION.json` records the executed tests and artifact checks.
`examples/test_results.txt` contains the actual unit-test log.
`PROVENANCE.json` links the unchanged source files to the parent archive by
SHA-256. `SHA256SUMS.json` and `tools/verify_package.py` verify this delivery's
file integrity, not identity, ownership, trusted timestamps, or physical
performance. See `LICENSE_NOTE.md` for the provenance and licensing status.

#include "tk1bit.h"
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *words[] = {"0", "1", "01", "101", "01101", "10101101",
                          "0110110101101", "101011010110110101101"};
    tk1_grammar state, saved;
    tk1_lane lane, old_lane;
    tk1_event event, old_event;
    uint8_t bit = 7u;
    unsigned depth, i, p, enabled, opcode, seam, mix;
    assert(tk1_grammar_init(NULL, 0u, 0u) == -1);
    assert(tk1_grammar_init(&state, 0u, 0u) == 0);
    saved = state;
    assert(tk1_grammar_init(&state, TK1_MAX_DEPTH + 1u, 0u) == -1);
    assert(memcmp(&saved, &state, sizeof state) == 0);
    assert(tk1_grammar_init(&state, 0u, 2u) == -1);
    assert(tk1_grammar_next(NULL, &bit) == -1);
    assert(tk1_grammar_next(&state, NULL) == -1);
    assert(bit == 7u);
    for (depth = 0u; depth < sizeof(words) / sizeof(words[0]); ++depth) {
        assert(tk1_grammar_init(&state, depth, 0u) == 0);
        for (i = 0u; words[depth][i] != '\0'; ++i) {
            assert(tk1_grammar_next(&state, &bit) == 1);
            assert(bit == (uint8_t)(words[depth][i] - '0'));
        }
        bit = 7u;
        assert(tk1_grammar_next(&state, &bit) == 0);
        assert(tk1_grammar_next(&state, &bit) == 0);
        assert(bit == 7u);
    }
    assert(tk1_grammar_init(&state, TK1_MAX_DEPTH, 1u) == 0);
    for (i = 0u; i < 100000u; ++i) {
        assert(tk1_grammar_next(&state, &bit) == 1);
        assert(bit <= 1u);
        assert(state.remaining <= TK1_MAX_DEPTH);
    }
    for (p = 0u; p < 2u; ++p)
    for (enabled = 0u; enabled < 2u; ++enabled)
    for (opcode = 0u; opcode < 2u; ++opcode)
    for (seam = 0u; seam < 2u; ++seam)
    for (mix = 0u; mix < 2u; ++mix) {
        assert(tk1_lane_init(&lane, p, enabled) == 0);
        assert(tk1_lane_step(&lane, opcode, seam, mix, &event) == 0);
        assert(event.opcode == opcode);
        assert(event.step == (opcode ^ 1u));
        assert(event.turn == opcode);
        assert(event.seam == seam);
        assert(event.orientation == (p ^ seam));
        assert(event.output == (opcode ^ ((p ^ seam) & enabled) ^ mix));
    }
    assert(tk1_lane_init(NULL, 0u, 0u) == -1);
    assert(tk1_lane_init(&lane, 0u, 0u) == 0);
    old_lane = lane;
    old_event = event;
    assert(tk1_lane_init(&lane, 2u, 0u) == -1);
    assert(tk1_lane_init(&lane, 0u, 2u) == -1);
    assert(tk1_lane_step(NULL, 0u, 0u, 0u, &event) == -1);
    assert(tk1_lane_step(&lane, 0u, 0u, 0u, NULL) == -1);
    assert(tk1_lane_step(&lane, 2u, 0u, 0u, &event) == -1);
    assert(tk1_lane_step(&lane, 0u, 2u, 0u, &event) == -1);
    assert(tk1_lane_step(&lane, 0u, 0u, 2u, &event) == -1);
    assert(memcmp(&lane, &old_lane, sizeof lane) == 0);
    assert(memcmp(&event, &old_event, sizeof event) == 0);
    printf("PASS: native grammar, 100000-bit depth-512 run, 32 lane combinations, errors; state_bytes=%zu\n", sizeof state);
    return 0;
}

/* Offline file writer only; this is not a GPIO, DAC or power-stage driver. */
#include "tk1bit.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int number(const char *text, uint64_t *out)
{
    char *end;
    unsigned long long parsed;
    const char *p = text;
    if (*p == '\0') return -1;
    while (*p != '\0') {
        if (*p < '0' || *p > '9') return -1;
        ++p;
    }
    errno = 0;
    parsed = strtoull(text, &end, 10);
    if (errno != 0 || *end != '\0' || parsed > UINT64_MAX) return -1;
    *out = (uint64_t)parsed;
    return 0;
}

int main(int argc, char **argv)
{
    tk1_grammar state;
    uint64_t depth, limit, seed = 0u, count = 0u;
    uint8_t bit = 0u, byte = 0u;
    unsigned used = 0u;
    int status = 0, failed = 0;
    FILE *out, *meta;
    char *meta_name;
    size_t name_size;
    if ((argc != 4 && argc != 5) || number(argv[1], &depth) != 0 ||
        number(argv[2], &limit) != 0 ||
        (argc == 5 && number(argv[4], &seed) != 0) ||
        depth > TK1_MAX_DEPTH || seed > 1u) {
        fprintf(stderr, "usage: %s DEPTH MAX_BITS OUTPUT.bin [SEED_0_OR_1]\n", argv[0]);
        return 2;
    }
    if (tk1_grammar_init(&state, (unsigned)depth, (unsigned)seed) != 0) return 2;
    out = fopen(argv[3], "wb");
    if (out == NULL) { perror("open output"); return 1; }
    while (count < limit && (status = tk1_grammar_next(&state, &bit)) == 1) {
        byte = (uint8_t)((byte << 1) | bit);
        ++used;
        ++count;
        if (used == 8u) {
            if (fputc(byte, out) == EOF) { failed = 1; break; }
            byte = 0u;
            used = 0u;
        }
    }
    if (!failed && used != 0u && fputc((int)(byte << (8u - used)), out) == EOF)
        failed = 1;
    if (fclose(out) != 0) failed = 1;
    if (failed || status < 0) {
        fprintf(stderr, "output failed; partial file removed\n");
        (void)remove(argv[3]);
        return 1;
    }
    name_size = strlen(argv[3]);
    if (name_size > SIZE_MAX - 6u) return 1;
    meta_name = (char *)malloc(name_size + 6u);
    if (meta_name == NULL) return 1;
    memcpy(meta_name, argv[3], name_size);
    memcpy(meta_name + name_size, ".json", 6u);
    meta = fopen(meta_name, "w");
    free(meta_name);
    if (meta == NULL) { perror("open metadata"); return 1; }
    if (fprintf(meta,
        "{\n  \"format\": \"TK-1BIT-RAW-v1\",\n  \"profile\": \"B1\",\n"
        "  \"depth\": %" PRIu64 ",\n  \"seed\": %" PRIu64 ",\n"
        "  \"bit_count\": %" PRIu64 ",\n  \"byte_count\": %" PRIu64 ",\n"
        "  \"sample_width_bits\": 1,\n  \"bit_order\": \"MSB-first\",\n"
        "  \"padding\": \"zero low bits of final byte\",\n  \"clock_hz\": null\n}\n",
        depth, seed, count, (count >> 3) + ((count & 7u) != 0u)) < 0)
        failed = 1;
    if (fclose(meta) != 0) failed = 1;
    if (failed) { fprintf(stderr, "metadata write failed\n"); return 1; }
    fprintf(stderr, "bits=%" PRIu64 " bytes=%" PRIu64 " state_bytes=%zu\n",
            count, (count >> 3) + ((count & 7u) != 0u), sizeof(state));
    return 0;
}

#ifndef TK1BIT_H
#define TK1BIT_H

#include <stdint.h>

/* Every opcode/lane is 0 or 1. uint8_t is the C host storage type.
 * Integer depth/index controls are not amplitude or coordinate samples.
 * No allocation, floating point, fixed-point coordinates, or libm needed.
 */
#define TK1_MAX_DEPTH 512u
#define TK1_PENDING_BYTES ((TK1_MAX_DEPTH + 7u) / 8u)

typedef struct {
    uint8_t pending[TK1_PENDING_BYTES]; /* one deferred-branch bit per level */
    uint16_t remaining;
    uint8_t symbol;
    uint8_t active;
} tk1_grammar;

typedef struct {
    uint8_t orientation;
    uint8_t apply_orientation;
} tk1_lane;

typedef struct {
    uint8_t opcode, step, turn, seam, orientation, output;
} tk1_event;

/* Return 0 on initialization success, -1 for invalid arguments.
 * Do not edit fields after initialization; reinitialize to restart.
 */
int tk1_grammar_init(tk1_grammar *state, unsigned depth, unsigned seed);

/* Return 1 with a bit, 0 at finite-generation end, -1 for null arguments.
 * The output pointer is unchanged at end or on error.
 */
int tk1_grammar_next(tk1_grammar *state, uint8_t *bit);

int tk1_lane_init(tk1_lane *state, unsigned orientation, unsigned apply_orientation);

/* On valid input: parity is updated FIRST, then output is generated.
 * Returns 0; returns -1 for invalid inputs without altering state/event.
 */
int tk1_lane_step(tk1_lane *state, unsigned opcode, unsigned seam,
                 unsigned mix, tk1_event *event);

#endif

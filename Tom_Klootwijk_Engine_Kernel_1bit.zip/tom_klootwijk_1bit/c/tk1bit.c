#include "tk1bit.h"
#include <stddef.h>
#include <string.h>

int tk1_grammar_init(tk1_grammar *state, unsigned depth, unsigned seed)
{
    if (state == NULL || depth > TK1_MAX_DEPTH || seed > 1u) return -1;
    memset(state, 0, sizeof(*state));
    state->remaining = (uint16_t)depth;
    state->symbol = (uint8_t)seed;
    state->active = 1u;
    return 0;
}

int tk1_grammar_next(tk1_grammar *state, uint8_t *bit)
{
    unsigned byte_index;
    if (state == NULL || bit == NULL) return -1;
    if (state->active == 0u) return 0;
    while (state->remaining != 0u) {
        unsigned level = (unsigned)--state->remaining;
        if (state->symbol != 0u) {
            state->pending[level >> 3] |= (uint8_t)(1u << (level & 7u));
            state->symbol = 0u;
        } else {
            state->symbol = 1u;
        }
    }
    *bit = state->symbol;
    /* Lowest pending level is the deepest unvisited right child. */
    for (byte_index = 0u; byte_index < TK1_PENDING_BYTES; ++byte_index) {
        uint8_t pending = state->pending[byte_index];
        if (pending != 0u) {
            unsigned offset = 0u;
            while ((pending & (uint8_t)(1u << offset)) == 0u) ++offset;
            state->pending[byte_index] &= (uint8_t)~(1u << offset);
            state->remaining = (uint16_t)((byte_index << 3) + offset);
            state->symbol = 1u;
            return 1;
        }
    }
    state->active = 0u;
    return 1;
}

int tk1_lane_init(tk1_lane *state, unsigned orientation, unsigned apply_orientation)
{
    if (state == NULL || orientation > 1u || apply_orientation > 1u) return -1;
    state->orientation = (uint8_t)orientation;
    state->apply_orientation = (uint8_t)apply_orientation;
    return 0;
}

int tk1_lane_step(tk1_lane *state, unsigned opcode, unsigned seam,
                 unsigned mix, tk1_event *event)
{
    if (state == NULL || event == NULL || opcode > 1u || seam > 1u || mix > 1u)
        return -1;
    if (state->orientation > 1u || state->apply_orientation > 1u) return -1;
    state->orientation ^= (uint8_t)seam;
    event->opcode = (uint8_t)opcode;
    event->step = (uint8_t)(opcode ^ 1u);
    event->turn = (uint8_t)opcode;
    event->seam = (uint8_t)seam;
    event->orientation = state->orientation;
    event->output = (uint8_t)(opcode ^ (state->orientation & state->apply_orientation) ^ mix);
    return 0;
}

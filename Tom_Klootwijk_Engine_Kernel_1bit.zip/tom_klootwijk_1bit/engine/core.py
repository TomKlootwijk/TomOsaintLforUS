"""B1: exact binary grammar, bit-packed storage and a one-bit event lane.

No floating-point or fixed-point coordinates, amplitude samples, PCM, or
numeric geometry exist in this module. Integers count/control execution;
every instruction and lane value is constrained to {0, 1}.
"""
from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass

MAX_DEPTH = 512
DEFAULT_BUDGET = 1_000_000


def _uint(value: int, name: str, maximum: int | None = None) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    if maximum is not None and value > maximum:
        raise ValueError(f"{name} must be <= {maximum}")
    return value


def _bit(value: int, name: str = "bit") -> int:
    return _uint(value, name, 1)


def _axiom(value: str) -> str:
    if not isinstance(value, str) or not value or any(c not in "01" for c in value):
        raise ValueError("axiom must be a nonempty binary string")
    return value


class Grammar1Bit(Iterator[int]):
    """Lazy simultaneous rewriting, 0 -> 1 and 1 -> 01, for one seed bit.

    Pending right children are ONE BIT PER DEPTH, not a stack of numerical
    coordinates or full words. Python's integers are host representations.
    The companion C implementation uses a fixed, packed 64-byte pending mask.
    """
    __slots__ = ("_remaining", "_symbol", "_pending", "_active")

    def __init__(self, depth: int, seed: int = 0) -> None:
        self._remaining = _uint(depth, "depth", MAX_DEPTH)
        self._symbol = _bit(seed, "seed")
        self._pending = 0
        self._active = 1

    def __iter__(self) -> Grammar1Bit:
        return self

    def __next__(self) -> int:
        if not self._active:
            raise StopIteration
        while self._remaining:
            self._remaining -= 1
            if self._symbol:
                # Visit left child 0 now; defer right child 1 at this depth.
                self._pending |= 1 << self._remaining
                self._symbol = 0
            else:
                self._symbol = 1
        result = self._symbol
        if self._pending:
            deepest = self._pending & -self._pending
            self._pending ^= deepest
            self._remaining = deepest.bit_length() - 1
            self._symbol = 1
        else:
            self._active = 0
        return result


def symbol_counts(depth: int, axiom: str = "0") -> tuple[int, int]:
    """Exact integer (zero, one) counts without expanding a word."""
    _uint(depth, "depth", MAX_DEPTH)
    _axiom(axiom)
    zero, one = axiom.count("0"), axiom.count("1")
    for _ in range(depth):
        zero, one = one, zero + one
    return zero, one


def iter_word(depth: int, axiom: str = "0", *, limit: int | None = None,
              budget: int = DEFAULT_BUDGET) -> Iterator[int]:
    """Return a bounded prefix of a specified FINITE generation.

    Successive generations of this grammar are not assumed to share a prefix.
    Validation occurs when this function is called, before iteration begins.
    """
    total = sum(symbol_counts(depth, axiom))
    _uint(budget, "budget")
    required = total if limit is None else min(total, _uint(limit, "limit"))
    if required > budget:
        raise ValueError("requested output exceeds budget; set limit or raise budget")

    def generate() -> Iterator[int]:
        emitted = 0
        for seed in axiom:
            if emitted == required:
                return
            for bit in Grammar1Bit(depth, int(seed)):
                yield bit
                emitted += 1
                if emitted == required:
                    return
    return generate()


@dataclass(frozen=True, slots=True)
class PackedBits:
    """Canonical MSB-first bytes plus exact logical bit count.

    Unused low bits in the final byte MUST be zero. Padding is not data.
    Python int objects yielded by iteration represent logical one-bit values.
    """
    data: bytes
    bit_count: int

    def __post_init__(self) -> None:
        if type(self.data) is not bytes:
            raise ValueError("data must be immutable bytes")
        _uint(self.bit_count, "bit_count")
        if len(self.data) != (self.bit_count + 7) // 8:
            raise ValueError("byte length must equal ceil(bit_count / 8)")
        used = self.bit_count & 7
        if used and (self.data[-1] & ((1 << (8 - used)) - 1)):
            raise ValueError("unused padding bits must be zero")

    def __len__(self) -> int:
        return self.bit_count

    def __iter__(self) -> Iterator[int]:
        for index in range(self.bit_count):
            yield (self.data[index >> 3] >> (7 - (index & 7))) & 1


def pack_bits(bits: Iterable[int], *, max_bits: int = DEFAULT_BUDGET) -> PackedBits:
    """Store eight logical samples per byte, not one byte per sample."""
    _uint(max_bits, "max_bits")
    data = bytearray()
    byte = count = used = 0
    for bit in bits:
        if count == max_bits:
            raise ValueError("bit budget exceeded")
        _bit(bit)
        byte = (byte << 1) | bit
        used += 1
        count += 1
        if used == 8:
            data.append(byte)
            byte = used = 0
    if used:
        data.append(byte << (8 - used))
    return PackedBits(bytes(data), count)


def unpack_bits(data: bytes, bit_count: int) -> Iterator[int]:
    return iter(PackedBits(data, bit_count))


def rewrite_packed(word: PackedBits, *, budget: int = DEFAULT_BUDGET) -> PackedBits:
    """One simultaneous rewrite of an already packed binary word."""
    if not isinstance(word, PackedBits):
        raise ValueError("word must be PackedBits")
    _uint(budget, "budget")
    required = word.bit_count + sum(word)
    if required > budget:
        raise ValueError("rewritten word exceeds budget")

    def children() -> Iterator[int]:
        for symbol in word:
            if symbol:
                yield 0
            yield 1
    return pack_bits(children(), max_bits=budget)


@dataclass(frozen=True, slots=True)
class BitEvent:
    """All six fields are logical single-bit lanes, never numerical geometry."""
    opcode: int
    step: int
    turn: int
    seam: int
    orientation: int
    output: int

    def __post_init__(self) -> None:
        for name in ("opcode", "step", "turn", "seam", "orientation", "output"):
            _bit(getattr(self, name), name)


class BitLane:
    """One-bit step/turn decoding and OPTIONAL, explicitly supplied seam parity.

    orientation' = orientation XOR seam
    output = opcode XOR (orientation' AND apply_orientation) XOR mix

    A seam is an external event, NOT inferred from the grammar or an SDF.
    Neither an XOR nor orientation parity is a physical pressure calculation.
    Each call is one accepted logical event; the caller supplies timing.
    """
    __slots__ = ("_orientation", "_apply_orientation")

    def __init__(self, *, orientation: int = 0, apply_orientation: int = 0) -> None:
        self._orientation = _bit(orientation, "orientation")
        self._apply_orientation = _bit(apply_orientation, "apply_orientation")

    @property
    def orientation(self) -> int:
        return self._orientation

    def process(self, opcode: int, *, seam: int = 0, mix: int = 0) -> BitEvent:
        # Validate the full event before mutating state.
        _bit(opcode, "opcode")
        _bit(seam, "seam")
        _bit(mix, "mix")
        self._orientation ^= seam
        output = opcode ^ (self._orientation & self._apply_orientation) ^ mix
        return BitEvent(opcode, opcode ^ 1, opcode, seam, self._orientation, output)

"""Float-free, packed one-bit reference kernel prepared for Tom Klootwijk.

B1 is a new binary implementation profile, not a numerical physics solver.
"""
from .core import (BitEvent, BitLane, Grammar1Bit, PackedBits, iter_word,
                   pack_bits, rewrite_packed, symbol_counts, unpack_bits)

__version__ = "0.2.0"
__all__ = ["BitEvent", "BitLane", "Grammar1Bit", "PackedBits", "iter_word",
           "pack_bits", "rewrite_packed", "symbol_counts", "unpack_bits"]

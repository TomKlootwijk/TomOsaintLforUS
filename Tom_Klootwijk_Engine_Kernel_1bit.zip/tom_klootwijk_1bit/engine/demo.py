"""Write a bounded packed 1-bit grammar stream. No audio playback or hardware I/O."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
from collections.abc import Iterable

from .core import DEFAULT_BUDGET, MAX_DEPTH, _bit, _uint, iter_word, symbol_counts


def write_bits(path: Path, bits: Iterable[int], *, max_bits: int = DEFAULT_BUDGET
               ) -> dict[str, int | str]:
    """Bounded-memory packed writer, replacing the target only after success."""
    _uint(max_bits, "max_bits")
    path = Path(path)
    digest = hashlib.sha256()
    count = byte = used = size = 0
    buffer = bytearray()
    descriptor, name = tempfile.mkstemp(prefix=".tk1bit-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            for bit in bits:
                if count == max_bits:
                    raise ValueError("output exceeds bit budget")
                _bit(bit)
                byte = (byte << 1) | bit
                count += 1
                used += 1
                if used == 8:
                    buffer.append(byte)
                    byte = used = 0
                if len(buffer) == 4096:
                    handle.write(buffer)
                    digest.update(buffer)
                    size += len(buffer)
                    buffer.clear()
            if used:
                buffer.append(byte << (8 - used))
            if buffer:
                handle.write(buffer)
                digest.update(buffer)
                size += len(buffer)
        os.replace(name, path)
    except BaseException:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass
        raise
    return {"file": path.name, "bit_count": count, "byte_count": size,
            "bit_order": "MSB-first", "padding": "zero low bits of final byte",
            "sha256": digest.hexdigest()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--depth", type=int, default=24, help=f"finite generation, 0..{MAX_DEPTH}")
    parser.add_argument("--seed", type=int, choices=(0, 1), default=0)
    parser.add_argument("--bits", type=int, default=65536, help="maximum emitted prefix length")
    parser.add_argument("--budget", type=int, default=DEFAULT_BUDGET)
    parser.add_argument("--output", type=Path, default=Path("run_output"))
    args = parser.parse_args()
    try:
        counts = symbol_counts(args.depth, str(args.seed))
        bits = iter_word(args.depth, str(args.seed), limit=args.bits, budget=args.budget)
        args.output.mkdir(parents=True, exist_ok=True)
        info = write_bits(args.output.joinpath("grammar.bin"), bits, max_bits=args.budget)
        metadata = {
            "format": "TK-1BIT-RAW-v1", "profile": "B1", "version": "0.2.0",
            "productions": {"0": "1", "1": "01"}, "seed": args.seed,
            "depth": args.depth, "finite_generation": True,
            "full_generation_bit_count": sum(counts),
            "requested_prefix_bits": args.bits,
            "truncated": info["bit_count"] < sum(counts),
            "sample_width_bits": 1, "clock_hz": None,
            "meaning": "raw grammar opcode; not PCM and not noise-shaped PDM",
            "seam_mapping": "none", "payload": info,
        }
        (args.output.joinpath("stream.json")).write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
        print(f"{info['bit_count']} bits in {info['byte_count']} bytes -> {args.output.joinpath('grammar.bin')}")
        print(f"Metadata -> {args.output.joinpath('stream.json')}")
        return 0
    except (OSError, ValueError) as exc:
        parser.exit(2, f"error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())

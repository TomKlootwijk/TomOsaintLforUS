# Tom Klootwijk — 1-bit Engine Kernel

**Version 0.2.0 · Binary execution profile B1 · Python + C99**

This replaces the previous floating-point reference path with a **direct,
float-free, packed one-bit grammar kernel**. Its instructions and output
samples are only `0` or `1`. Eight samples occupy one byte in the delivered
binary files. There is no floating-point coordinate, fixed-point coordinate,
multibit amplitude, PCM/WAV, or float-to-bit quantizer stage.

The exact productions remain:

```text
0 -> 1
1 -> 01
```

The instruction decoder exposes `0 = step request`, `1 = turn/branch request`.
It does not substitute a numerical angle or invent a geometric branch policy.
An optional one-bit seam input updates orientation parity; no crossings are
invented or inferred from the grammar. Raw grammar output is the default.

## Run immediately — Python

Python 3.10+; standard library only. From this extracted directory:

```sh
python -m unittest discover -s tests -v
python -m engine.demo --depth 24 --bits 65536 --output run_output
python tools/verify_package.py
```

Use `python3` where that is your Python command. The demo writes **65,536
logical bits in 8,192 bytes** to `run_output/grammar.bin`, with the exact bit
count, bit order, generation and SHA-256 in `run_output/stream.json`. It does
not play sound, access the network, or write to hardware.

An available C compiler enables the native comparison tests automatically;
without a compiler, those tests are explicitly skipped, not reported as passed.

## Native kernel — C99

```sh
make
./build/tk1bit 24 65536 run_output/c_grammar.bin
```

Run the Python demo first to create `run_output`, or create that directory
manually. Without Make, the equivalent compiler command is:

```sh
cc -std=c99 -O2 c/tk1bit.c c/main.c -o tk1bit
./tk1bit 24 65536 run_output/c_grammar.bin
```

Native command arguments are `DEPTH MAX_BITS OUTPUT.bin [SEED_0_OR_1]`.
The native writer creates `OUTPUT.bin.json` alongside the raw payload. It
uses the same MSB-first packing as Python. Both stop at the end of the chosen
finite generation, even when the requested limit is larger.

`c/tk1bit.c` / `c/tk1bit.h` are the standalone native library. Its generator
uses **64 bytes of packed deferred-branch state** plus integer depth and
single-bit-valued flags. The whole generator struct was **68 bytes on the
validated host**. It neither stores a complete word nor allocates heap memory.
The desktop file-writing wrapper is separate and does allocate its output
metadata filename.

## Import the binary kernel

```python
from engine import BitLane, iter_word, pack_bits, unpack_bits

packed = pack_bits(iter_word(12))
assert packed.bit_count == 233
assert len(packed.data) == 30
assert list(unpack_bits(packed.data, packed.bit_count)) == list(iter_word(12))

lane = BitLane()  # default: pass raw opcode through unchanged
for opcode in iter_word(12):
    event = lane.process(opcode)
    assert event.output in (0, 1)
    # event.step and event.turn are also one-bit request lanes.
```

For an application with an independently defined seam-crossing rule:

```python
lane = BitLane(apply_orientation=1)  # opt-in transport mapping
first = lane.process(0, seam=1)     # external crossing on THIS event
assert first.orientation == 1 and first.output == 1
second = lane.process(0, seam=1)
assert second.orientation == 0 and second.output == 0
```

These are Boolean transport operations, not a distance computation or a
calibrated acoustic polarity mapping. `mix=0` is the default; `mix=1` applies
an additional explicit XOR. Step/turn decoding always uses the original
opcode, not the transformed transport bit.

## What “1-bit” means here

| Layer | Representation |
|---|---|
| Grammar alphabet / accepted instruction | Exactly one logical bit |
| Output sample / seam / orientation / XOR input | Each exactly one logical bit |
| Deferred branches | One packed pending flag per possible depth |
| Saved binary payload | Eight bits per byte, with counted final-byte padding |
| Host control and metadata | Integer depth, lengths and indices; not sample amplitudes |

This is **not** a claim that the entire machine has one bit of RAM, that a
Python integer occupies one physical bit, or that the C compiler targets a
one-bit CPU. The native C interface uses `uint8_t` storage constrained to
values `0` and `1`; its pending flags and binary payloads really are packed.
No numerical geometry or amplitude is hidden in a wider intermediate type.

## Contents

`engine/` contains the Python kernel and streaming writer. `c/` contains the
native kernel, command-line writer and self-test. `tests/` contains the 57-test
suite, including 81 Python/C packed-output comparisons within its test cases.
`examples/` contains raw one-bit payloads and their metadata, not a PCM preview.
`docs/` specifies the binary contract, source boundary and migration from P0.
`validation/` records the actual test and sanitizer runs. `SHA256SUMS.json`
and `tools/verify_package.py` check delivery integrity.

Regenerate the examples into a separate directory:

```sh
python tools/reproduce_examples.py --output regenerated_examples
python tools/run_validation.py --output validation_rerun
```

## Scope and changes from the previous delivery

This is a **new binary implementation profile**, not a bit-exact re-encoding
of the previous floating-point waveform. The previous numerical trajectory,
SDF helpers, sinusoidal signal and 16-bit WAV are deliberately absent. The
kernel preserves the binary grammar and exposes symbolic step/turn events;
it does not silently replace the missing physical algorithms with numerical
approximations.

The corpus motivates geometry grown from words, golden-ratio organization,
and non-orientable traversal. It does not provide an executable embedding,
a seam-crossing detector, a numerical distance oracle, a timing/driver
contract, or a complete physical propagation model. Those are not claimed
as implemented here. A raw grammar stream is also **not** automatically a
noise-shaped delta-sigma stream, alias-free audio, or a safe amplifier input.
There is no dither, clock-jitter model, reconstruction filter, hardware driver,
power-stage control, or acoustic focusing/energy-recirculation validation.

The source rules, implementation choices and exclusions are mapped in
`docs/SOURCE_MAP.md`; the exact contract is in `docs/KERNEL_SPEC.md`.

#!/usr/bin/env python3
"""Run this package's tests and write a machine-readable validation record."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import io
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("validation_rerun"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    log = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    text = log.getvalue()
    (args.output / "tests.txt").write_text(text, encoding="utf-8")
    print(text, end="")
    compiler = shlex.split(os.environ.get("CC", "cc"))
    compiler_version = None
    if compiler and shutil.which(compiler[0]):
        proc = subprocess.run([*compiler, "--version"], capture_output=True, text=True)
        compiler_version = proc.stdout.splitlines()[0] if proc.stdout else proc.stderr.splitlines()[0]
    record = {
        "profile": "B1", "kernel_version": "0.2.0",
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "platform": platform.platform(),
        "compiler": compiler_version, "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors),
        "skipped": len(result.skipped), "success": result.wasSuccessful(),
        "scope": "software properties and Python/C equivalence only; no physical validation",
    }
    (args.output / "tests.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())

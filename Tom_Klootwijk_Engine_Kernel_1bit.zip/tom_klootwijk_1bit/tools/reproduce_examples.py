#!/usr/bin/env python3
"""Regenerate the delivered binary examples without touching the originals."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from engine import BitLane, iter_word, pack_bits  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("regenerated_examples"))
    args = parser.parse_args()
    output = args.output.resolve()
    for label, depth, bits in (("depth12", 12, 233), ("depth24", 24, 65536)):
        subprocess.run([sys.executable, "-m", "engine.demo", "--depth", str(depth),
                        "--bits", str(bits), "--output", str(output / label)], cwd=ROOT, check=True)
    path = output / "seam_demo"
    path.mkdir(parents=True, exist_ok=True)
    opcodes = list(iter_word(8, limit=16))
    # Explicit artificial fixture, not a topology/geometry inference.
    seams = [int(i in (3, 10)) for i in range(16)]
    lane = BitLane(apply_orientation=1)
    events = [lane.process(opcode, seam=seam) for opcode, seam in zip(opcodes, seams)]
    streams = {
        "grammar.bin": opcodes,
        "seam.bin": seams,
        "orientation.bin": [e.orientation for e in events],
        "output.bin": [e.output for e in events],
    }
    metadata = {
        "profile": "B1", "format": "TK-1BIT-RAW-v1", "depth": 8, "seed": 0,
        "bit_count_per_lane": 16, "sample_width_bits": 1, "clock_hz": None,
        "apply_orientation": 1, "initial_orientation": 0, "mix": 0,
        "seam_event_indices_zero_based": [3, 10],
        "note": "Artificial external seam fixture, not a geometric trajectory or physical signal.",
        "payloads": {},
    }
    for name, bits in streams.items():
        packed = pack_bits(bits)
        (path / name).write_bytes(packed.data)
        metadata["payloads"][name] = {
            "bit_count": packed.bit_count, "byte_count": len(packed.data),
            "bit_order": "MSB-first", "sha256": hashlib.sha256(packed.data).hexdigest(),
        }
    (path / "streams.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(f"Seam-interface fixture -> {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# Migration from the previous kernel

B1 replaces P0; it is not a wrapper that quantizes the old floating-point
samples. The previous ZIP remains unchanged. B1 lives in its own extracted
directory, `tom_klootwijk_1bit`.

| P0 interface or output | B1 replacement |
|---|---|
| `iter_word` and source grammar | Same production order; new packed pending-mask iterator; bounded finite generation remains explicit |
| `symbol_counts` | Exact integer recurrence retained |
| `rewrite_once` on strings | `rewrite_packed(PackedBits)` on binary payloads |
| `pack_bits` returning `(bytes, count)` | `PackedBits` with `.data` and `.bit_count` |
| `unpack_bits` returning a list | Canonical-padding validation and a lazy iterator; use `list(...)` only when needed |
| `trace_word`, numerical heading and trajectory | `BitLane.process` and one-bit step/turn requests; no numerical motion inferred |
| `klein_project`, numerical chart scalar | External seam-event interface and a one-bit orientation label; no chart evaluation |
| Pitch helpers, float SDFs and polynomial scalar blend | Not in the binary kernel; no hidden fixed-point substitute |
| `sigma_delta` float-input modulator | Not included; raw grammar is already binary and is not mislabeled PDM |
| `reference_waveform.wav`, floating-point signal CSV | Removed; delivered samples are packed `.bin` files |
| Python-only numerical demonstrator | Python model plus matching standalone C99 binary generator and Boolean lane |

Old code that expects positions, scalar distances or pressure values cannot
be run unchanged against B1. That is an explicit change in implementation
profile, not an assertion that continuous quantities have been recovered from
one bit without a defined model.

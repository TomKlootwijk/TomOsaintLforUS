# B1 executable contract

## 1. Source-derived core and explicit defaults

The final grammar framing in `Tone.pdf`, pages 21–22, and section IV of
`Pasted markdown(9).md` supplies a binary alphabet, `0 -> 1`, `1 -> 01`, and
step versus turn/branch instruction meanings. B1 uses a default **seed 0**,
**finite depth 24** and **prefix limit 65,536** for the demonstration. These
are implementation defaults, not values recovered from the corpus.

For simultaneous substitution R, the selected word is R^depth(seed). A
multi-symbol Python axiom is expanded by concatenating each seed's expansion
in original order. The native generator accepts a single seed bit. Depth is
restricted to 0..512 in both implementations.

The default seed produces:

| Depth | Word | Zero count | One count |
|---:|---|---:|---:|
| 0 | 0 | 1 | 0 |
| 1 | 1 | 0 | 1 |
| 2 | 01 | 1 | 1 |
| 3 | 101 | 1 | 2 |
| 4 | 01101 | 2 | 3 |
| 5 | 10101101 | 3 | 5 |

Counts follow `(z, o) -> (o, z + o)`. This exact integer recurrence carries
the Fibonacci organization without computing a floating-point golden ratio.
No numerical turn angle or geometric branch tree is substituted for the
source's turn/branch instruction. B1 issues the request, not a solved motion.

A prefix always belongs to the **specified finite generation**. Adjacent
generations are not assumed to share a prefix. Finite exhaustion is explicit;
there is no automatic loop, repeat, concatenation of generations, or dither.

## 2. Packed deferred-branch streaming algorithm

Generator state is `(remaining, symbol, pending, active)`:

* `remaining` is an integer depth control, initially the requested depth.
* `symbol` is a bit, initially the seed.
* `pending` is a packed set of deferred right-child flags, initially empty.
* `active` is a bit, initially 1.

While `remaining > 0`, reduce it by one. A symbol `0` becomes `1`. A symbol
`1` stores a pending-right flag at the new remaining level, then becomes `0`.
At level zero, emit the current bit. If any pending flag exists, clear the
lowest-index set flag, resume at its level with symbol `1`, and remain active.
Otherwise mark the generator exhausted.

A remaining level uniquely identifies one ancestor's deferred right child
along the active depth-first path. Lower remaining levels are deeper, so the
lowest pending flag is resumed first. This yields left-to-right simultaneous
substitution order without storing an expanded intermediate word. Python
uses a packed integer mask; C uses 64 bytes for 512 branch flags. No frame
stores a floating-point value, coordinate vector, or amplitude sample.

The C struct also stores `uint16_t remaining`, `uint8_t symbol` and
`uint8_t active`. Its host `sizeof` was 68 bytes in the validation run; a C
implementation's alignment rules can affect total struct size. Control words
are multibit integers. Logical data and pending flags are one-bit values.

The native generator allocates no heap memory and does not call itself
recursively. Work is not guaranteed to be constant per emitted sample: a call
can descend and scan pending levels. This is not a real-time clocked driver.
Output storage still scales with the number of bits retained; streaming does
not make an arbitrarily long saved payload occupy zero memory.

## 3. Single-bit event interface

Every accepted opcode generates these separate logical bit lanes:

```text
step = opcode XOR 1
turn = opcode
orientation_next = orientation XOR seam
output = opcode XOR (orientation_next AND apply_orientation) XOR mix
```

The lane's default initial parity, seam input, XOR mix and
`apply_orientation` switch are all 0. Consequently raw output equals opcode
by default. Each call is one accepted event. No background clock advances the
state. There is no event-time duration inferred from host execution speed.

The seam event applies to the **current** instruction. A caller-supplied seam
bit toggles orientation parity, even when output mapping is disabled. With
mapping enabled the updated parity affects that same event's output. A
second crossing restores the previous parity. XOR does not change the stored
grammar, raw opcode or step/turn requests.

These are explicit B1 Boolean interface choices. The source does not provide
a uniquely executable seam-crossing test or prove that this XOR convention is
a physical pressure transformation. No periodic seam schedule is built in.
The demonstration in `examples/seam_demo/` supplies an artificial schedule
solely to test the interface; it is not a recovered topological trajectory.

No distance, field magnitude, SDF zero-crossing, rotation angle, physical
branch placement, chart coordinate or pressure level is returned. A geometric
embedding would have to define and justify those separately. In B1 the word
remains a symbolic instruction/coordinate description rather than becoming a
hidden multibit numerical geometry stage.

## 4. Packed binary representation

Raw file format identifier: `TK-1BIT-RAW-v1`.

One logical sample or opcode is one bit. The first sample is bit 7 of byte 0,
the second bit 6, and so on. Only unused LOW bits of the final byte are zero
padded. Data length must equal `(bit_count + 7) // 8`. The valid bit count is
mandatory metadata; padding bits must never be replayed as extra samples.

Examples: `101` -> hex `a0`, count 3. `10101101` -> hex `ad`, count 8.
An empty stream is zero bytes with count 0. The depth-12 seed-0 word is 233
bits in 30 bytes; seven low bits of the last byte are padding.

There is no file header mixed into the raw payload. The Python writer puts
metadata in `stream.json`; the C writer uses `OUTPUT.bin.json`. Both include
bit count, byte count and order. The Python file also records SHA-256, full
finite-generation length, prefix status and grammar rules. No sampling clock
is silently assigned: `clock_hz` is null. These files are not WAV, PCM, DSD or
a claim of delta-sigma modulation.

`PackedBits` enforces immutable bytes, canonical byte length and zero padding.
`pack_bits` accepts integer values 0 or 1 only; it rejects Python `bool`,
floating-point values and out-of-range symbols rather than coercing them.
`unpack_bits` validates immediately and returns a lazy iterator. `write_bits`
uses a 4,096-byte staging buffer and replaces its target only after successful
payload construction. Payload and JSON metadata are separate files, not an
atomic two-file transaction.

## 5. Execution limits, host types and error behavior

Python's public wrapper rejects invalid depths, seeds, axioms, counts and
budgets before expansion starts. Its default emission budget is 1,000,000
bits. An explicit limit may request a shorter prefix of a huge generation.
`Grammar1Bit` is the lower-level iterator without an emission budget; callers
using it directly are responsible for bounding consumption.

Python `BitLane.process` validates the whole event before mutating parity.
`BitEvent` fields validate as logical bits. Python object overhead does not
change the bitstream format; it also is not claimed to be a one-bit memory
allocation per returned Python object.

Native API:

```c
int tk1_grammar_init(tk1_grammar *state, unsigned depth, unsigned seed);
int tk1_grammar_next(tk1_grammar *state, uint8_t *bit);
int tk1_lane_init(tk1_lane *state, unsigned orientation, unsigned apply_orientation);
int tk1_lane_step(tk1_lane *state, unsigned opcode, unsigned seam,
                 unsigned mix, tk1_event *event);
```

Initialization and lane-step calls return 0 on success and -1 on invalid
arguments. `tk1_grammar_next` returns 1 for an emitted bit, 0 at exhaustion and
-1 for null arguments. Its output pointer is unchanged at exhaustion or on
error. Initialize before use, do not manually modify the public struct's
fields, and reinitialize to restart. The native CLI accepts nonnegative
integer text and a maximum output count representable in `uint64_t`. The
library itself uses no total-generation counter and can emit bounded prefixes
at depth 512. C flags occupy byte-sized host objects constrained to bits.

## 6. Validation boundary

The delivered suite tests substitution order, both seeds, multi-symbol Python
axioms, finite termination, resuming, depth limits, packed pending-state
bounds, canonical packing, padding, output budgets, streaming-file behavior,
all 32 combinations of the Boolean lane truth table, and error handling.
It also checks for floating-point types/constants and numerical division in
the production Python modules, and float/double types or `math.h` in C.
Source checks are guards for this implementation, not a universal theorem
about arbitrary future edits.

Native and Python outputs are compared over 81 generation/prefix/seed cases.
The native self-test additionally emits 100,000 bits at depth 512 and checks
all lane combinations. Compiler sanitizer results cover that executed native
self-test; they are not an exhaustive proof of all software behavior.

No hardware timing, analog behavior, noise shaping, geometric embedding,
caustics, acoustic focusing, power efficiency, alias suppression, or physical
energy recirculation was tested or established by these software results.

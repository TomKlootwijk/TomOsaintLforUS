# Source boundary and implementation decisions

## Source material used

The reference basis is the two original uploads: `Tone.pdf` and
`Pasted markdown(9).md`, together with the previously delivered
`Tom_Klootwijk_Engine_Kernel.zip`. Exact input hashes are in `PROVENANCE.json`.
The originals and previous numerical kernel are not copied into this ZIP.

| Source location | Source content | B1 treatment |
|---|---|---|
| Tone.pdf, p. 21, “The 1-Bit L-System Alphabet” | Abandoning floats; binary words; 0 steps and 1 branches/rotates | Binary opcodes, no numerical geometry or amplitude path; one-bit step and turn/branch requests |
| Tone.pdf, p. 22, “Replacing the Binary Search Tree with Grammar”; markdown section IV | 0 -> 1 and 1 -> 01; grammar replaces searching a coordinate tree | Exact simultaneous substitution, same production order; packed lazy generator |
| Tone.pdf, pp. 21–22, “Topological Traversal” | Orientation/phase inversion associated with non-orientable traversal | Optional external seam bit and a parity lane; no invented crossing detector |
| Tone.pdf, p. 22, “Zero Rasterization”; markdown section V | Stream one-bit words without converting back to floats | Raw one-bit binary payload; no PCM or float-to-bit conversion |
| Tone.pdf, p. 19; markdown section I | Earlier delta-sigma and dither framing | Not equated to the raw grammar. No claim of implemented noise shaping or jitter |
| Previous kernel, engine/core.py and KERNEL_SPEC.md | Proposed float chart, analytic fields and reference waveform | Removed from B1; not silently quantized or described as still implemented |

The original exports contain AI/search-generated explanatory passages. This
mapping identifies what the supplied corpus says without treating every
physical claim in those passages as established or independently attributing
every passage to a particular human author.

## New, explicitly declared implementation choices

The default seed and finite-depth/prefix controls, the packed pending-mask
algorithm, the binary file convention, the event-call interface, and the
optional parity-to-output XOR convention were implemented for this delivery.
They are not represented as original recovered author code.

Step and turn/branch are request lanes, not a recovered numerical trajectory.
The corpus does not settle an exact turn-angle rule, geometric branch policy,
embedding, seam detection, clock or output transfer function. This delivery
therefore does not insert a floating-point, fixed-point or voxel-grid model
to make those unspecified components appear complete.

The final grammar-centered framing supplies the binary kernel. The earlier
numeric-field, delta-sigma and hardware claims remain separate and are not
silently reconciled into a claimed working physical engine. The one-bit change
does not establish physical focusing, absence of aliasing or recirculated
energy; those would require their own definitions and measurements.

# One-bit reference payloads

`depth12/grammar.bin` is the complete seed-0 generation 12: **233 bits in 30
bytes**. Its final byte has seven zero padding bits. `depth24/grammar.bin`
is the first **65,536 bits in 8,192 bytes** of seed-0 generation 24, not the
entire generation. The respective `stream.json` files provide exact counts,
hashes, grammar, prefix status and packing conventions.

`seam_demo/` demonstrates only the Boolean seam interface. It takes 16
instructions from generation 8 and injects external crossing events at
zero-based indices 3 and 10. The four two-byte files carry raw opcode, seam,
orientation and mapped output as separate 1-bit lanes. Its `streams.json`
records the artificial schedule and each payload's SHA-256. No geometry or
physical crossing was calculated, and these files are not acoustic samples
with a calibrated clock or level.

All payloads are MSB first. Only the declared bit count is meaningful; discard
low-bit padding in a partial final byte. These are binary files, not text
characters `0`/`1`, eight-bit PCM, WAV audio or a noise-shaped PDM recording.
No payload is automatically played or sent to a device.

Reproduce these payloads and metadata from the package root:

```sh
python tools/reproduce_examples.py --output regenerated_examples
```

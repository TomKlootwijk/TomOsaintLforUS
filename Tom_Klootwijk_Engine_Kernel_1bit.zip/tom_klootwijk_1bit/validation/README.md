# Recorded validation — B1

`tests.json` and `tests.txt` record the delivered version's **57 successful
unit tests, zero failures, zero errors and zero skips**. That run included the
native compiler-dependent tests, not only Python tests.

Within the native comparison tests, 44 complete-generation seed/depth cases,
22 deep-prefix cases and 15 partial-byte/prefix cases compare C payloads with
Python payloads: **81 bit-for-bit comparisons** in total. Both seed values
are exercised. Tested finite depths include 512, with bounded prefixes rather
than an attempt to materialize that enormous complete generation.

`native_checks.json` and `native_checks.txt` record a C self-test compiled and
run with GCC AddressSanitizer and UndefinedBehaviorSanitizer, plus a separate
Clang build and run with strict warnings. All recorded commands returned 0.
The self-test includes a 100,000-bit depth-512 run, the 32-case Boolean lane
truth table and invalid-argument behavior. Its generator struct occupied
68 bytes on this host, including the 64-byte packed pending mask.

These are software validations, not throughput benchmarks, circuit synthesis,
hardware timing certification, or evidence of a physical acoustic mechanism.
The native sanitizer run covers its actual test paths, not every possible
program execution. SHA-256 manifest checks establish file consistency, not
identity or authorship authentication.

Rerun without overwriting this delivered record:

```sh
python tools/run_validation.py --output validation_rerun
```

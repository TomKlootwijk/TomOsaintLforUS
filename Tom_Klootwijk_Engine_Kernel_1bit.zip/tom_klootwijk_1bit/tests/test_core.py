from __future__ import annotations

import ast
import hashlib
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest

from engine import (BitEvent, BitLane, Grammar1Bit, PackedBits, iter_word,
                    pack_bits, rewrite_packed, symbol_counts, unpack_bits)
from engine.core import MAX_DEPTH
from engine.demo import write_bits

ROOT = Path(__file__).resolve().parents[1]


def oracle(depth, seed="0"):
    # Independent small-word oracle: simultaneous string substitution.
    for _ in range(depth):
        seed = "".join("1" if bit == "0" else "01" for bit in seed)
    return [int(bit) for bit in seed]


class GrammarTests(unittest.TestCase):
    def test_known_generations(self):
        expected = ["0", "1", "01", "101", "01101", "10101101", "0110110101101"]
        for depth, word in enumerate(expected):
            self.assertEqual(list(Grammar1Bit(depth)), [int(x) for x in word])

    def test_independent_oracle_both_seeds(self):
        for depth in range(22):
            for seed in (0, 1):
                with self.subTest(depth=depth, seed=seed):
                    self.assertEqual(list(Grammar1Bit(depth, seed)), oracle(depth, str(seed)))

    def test_depth12_counts(self):
        self.assertEqual(symbol_counts(12), (89, 144))
        self.assertEqual(len(list(iter_word(12))), 233)

    def test_counts_match_expansion(self):
        for depth in range(18):
            for axiom in ("0", "1", "01", "1001"):
                word = list(iter_word(depth, axiom))
                self.assertEqual(symbol_counts(depth, axiom), (word.count(0), word.count(1)))

    def test_multi_symbol_axiom(self):
        for depth in range(10):
            self.assertEqual(list(iter_word(depth, "10010")), oracle(depth, "10010"))

    def test_prefixes_preserve_left_to_right_order(self):
        expected = oracle(14, "10")
        for limit in (0, 1, 2, 7, 8, 9, 232, 233, len(expected), len(expected) + 1):
            self.assertEqual(list(iter_word(14, "10", limit=limit)), expected[:limit])

    def test_successive_generations_not_assumed_prefixes(self):
        self.assertEqual(next(iter_word(8)), 0)
        self.assertEqual(next(iter_word(9)), 1)

    def test_eof_is_repeatable(self):
        state = Grammar1Bit(0, 1)
        self.assertEqual(next(state), 1)
        for _ in range(3):
            with self.assertRaises(StopIteration):
                next(state)

    def test_resume_has_no_restart(self):
        state = Grammar1Bit(16)
        first = list(itertools.islice(state, 127))
        second = list(itertools.islice(state, 129))
        self.assertEqual(first + second + list(state), oracle(16))

    def test_deep_prefix_binary_and_bounded_pending_state(self):
        state = Grammar1Bit(MAX_DEPTH, 1)
        for _ in range(10000):
            self.assertIn(next(state), (0, 1))
            self.assertLessEqual(state._pending.bit_length(), MAX_DEPTH)
            self.assertLessEqual(state._remaining, MAX_DEPTH)

    def test_bitpacked_pending_algorithm_across_byte_boundaries(self):
        # The C parity tests independently cover the same deep profiles.
        for depth in (7, 8, 9, 15, 16, 17, 63, 64, 65, 255, 256, 511, 512):
            self.assertEqual(len(list(iter_word(depth, limit=16))), min(16, sum(symbol_counts(depth))))

    def test_budget_failure_before_iteration(self):
        with self.assertRaises(ValueError):
            iter_word(512)
        with self.assertRaises(ValueError):
            iter_word(12, budget=232)

    def test_exact_budget_and_zero_budget(self):
        self.assertEqual(len(list(iter_word(12, budget=233))), 233)
        self.assertEqual(list(iter_word(512, limit=0, budget=0)), [])

    def test_bad_depth_values(self):
        for bad in (-1, MAX_DEPTH + 1, True, 1.5, "12", None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                Grammar1Bit(bad)
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                symbol_counts(bad)

    def test_bad_seed_values(self):
        for bad in (-1, 2, True, 0.0, "0", None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                Grammar1Bit(1, bad)

    def test_bad_axioms(self):
        for bad in ("", "2", "01x", " 0", 0, None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                iter_word(0, bad)

    def test_bad_limits_and_budgets(self):
        for bad in (-1, True, 1.0, "1"):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                iter_word(3, limit=bad)
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                iter_word(3, budget=bad)


class PackingTests(unittest.TestCase):
    def test_msb_first_known_bytes(self):
        self.assertEqual(pack_bits([1, 0, 1]), PackedBits(b"\xa0", 3))
        self.assertEqual(pack_bits(iter_word(5)), PackedBits(b"\xad", 8))

    def test_233_bits_are_30_bytes(self):
        packed = pack_bits(iter_word(12))
        self.assertEqual((packed.bit_count, len(packed.data)), (233, 30))
        self.assertEqual(packed.data[-1] & 127, 0)

    def test_empty(self):
        self.assertEqual(pack_bits([], max_bits=0), PackedBits(b"", 0))
        self.assertEqual(list(unpack_bits(b"", 0)), [])

    def test_all_one_byte_values(self):
        for value in range(256):
            packed = PackedBits(bytes([value]), 8)
            self.assertEqual(pack_bits(packed), packed)

    def test_roundtrip_every_partial_length(self):
        rng = random.Random(183)
        for length in range(300):
            word = [rng.randrange(2) for _ in range(length)]
            packed = pack_bits(word)
            self.assertEqual(list(unpack_bits(packed.data, length)), word)
            self.assertEqual(len(packed.data), (length + 7) // 8)

    def test_rejects_wrong_byte_lengths(self):
        for data, count in ((b"", 1), (b"\0", 0), (b"\0\0", 1), (b"\0", 9)):
            with self.subTest(data=data, count=count), self.assertRaises(ValueError):
                PackedBits(data, count)

    def test_rejects_nonzero_padding(self):
        for count in range(1, 8):
            with self.assertRaises(ValueError):
                PackedBits(b"\xff", count)

    def test_rejects_mutable_or_nonbinary_payload(self):
        for bad in (bytearray(b"\0"), "0", [0], None):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                PackedBits(bad, 1)

    def test_rejects_bad_counts(self):
        for count in (-1, True, 0.0, "0"):
            with self.subTest(count=count), self.assertRaises(ValueError):
                PackedBits(b"", count)

    def test_rejects_non_bit_symbols(self):
        for bit in (-1, 2, True, 0.0, "1", None):
            with self.subTest(bit=bit), self.assertRaises(ValueError):
                pack_bits([0, bit])

    def test_packing_budget(self):
        self.assertEqual(pack_bits([1], max_bits=1).bit_count, 1)
        with self.assertRaises(ValueError):
            pack_bits([1], max_bits=0)
        with self.assertRaises(ValueError):
            pack_bits([0, 1], max_bits=1)

    def test_rewrite_matches_lazy_grammar(self):
        packed = PackedBits(b"\0", 1)
        for depth in range(21):
            self.assertEqual(packed, pack_bits(iter_word(depth)))
            packed = rewrite_packed(packed)

    def test_rewrite_multiword_and_empty(self):
        self.assertEqual(list(rewrite_packed(pack_bits([1, 0, 1]))), [0, 1, 1, 0, 1])
        self.assertEqual(rewrite_packed(PackedBits(b"", 0)), PackedBits(b"", 0))

    def test_rewrite_budget_and_types(self):
        with self.assertRaises(ValueError):
            rewrite_packed(pack_bits([1]), budget=1)
        with self.assertRaises(ValueError):
            rewrite_packed("1")


class LaneTests(unittest.TestCase):
    def test_default_output_is_raw_opcode(self):
        lane = BitLane()
        for opcode in iter_word(12):
            event = lane.process(opcode)
            self.assertEqual(event.output, opcode)
            self.assertEqual(event.step, opcode ^ 1)
            self.assertEqual(event.turn, opcode)
            self.assertEqual(event.orientation, 0)

    def test_full_boolean_truth_table(self):
        for p, enabled, opcode, seam, mix in itertools.product((0, 1), repeat=5):
            lane = BitLane(orientation=p, apply_orientation=enabled)
            event = lane.process(opcode, seam=seam, mix=mix)
            self.assertEqual(event, BitEvent(opcode, opcode ^ 1, opcode, seam,
                                            p ^ seam, opcode ^ ((p ^ seam) & enabled) ^ mix))

    def test_two_seams_restore_parity(self):
        lane = BitLane(apply_orientation=1)
        self.assertEqual(lane.process(0, seam=1).output, 1)
        self.assertEqual(lane.process(0, seam=0).output, 1)
        self.assertEqual(lane.process(0, seam=1).output, 0)
        self.assertEqual(lane.orientation, 0)

    def test_seam_affects_current_event_not_next(self):
        lane = BitLane(apply_orientation=1)
        self.assertEqual(lane.process(1, seam=1).output, 0)

    def test_turn_request_not_changed_by_transport_parity(self):
        lane = BitLane(apply_orientation=1)
        event = lane.process(1, seam=1)
        self.assertEqual((event.opcode, event.step, event.turn, event.output), (1, 0, 1, 0))

    def test_seam_output_mapping_is_explicit_opt_in(self):
        lane = BitLane()
        event = lane.process(0, seam=1)
        self.assertEqual((event.orientation, event.output), (1, 0))

    def test_mix_is_xor_not_arithmetic_addition(self):
        lane = BitLane()
        self.assertEqual(lane.process(1, mix=1).output, 0)

    def test_bad_lane_initialization(self):
        for bad in (-1, 2, True, 0.0, "1"):
            with self.assertRaises(ValueError):
                BitLane(orientation=bad)
            with self.assertRaises(ValueError):
                BitLane(apply_orientation=bad)

    def test_bad_event_does_not_mutate_parity(self):
        lane = BitLane(orientation=1)
        for kwargs in ({"opcode": 2}, {"opcode": 0, "seam": 2},
                       {"opcode": 0, "seam": 1, "mix": 2}):
            with self.assertRaises(ValueError):
                lane.process(**kwargs)
            self.assertEqual(lane.orientation, 1)

    def test_event_constructor_requires_bit_lanes(self):
        with self.assertRaises(ValueError):
            BitEvent(0, 1, 0, 0, 0, 2)

    def test_long_seam_stream(self):
        rng = random.Random(37)
        lane = BitLane(apply_orientation=1)
        parity = 0
        for opcode in iter_word(24, limit=10000):
            seam, mix = rng.randrange(2), rng.randrange(2)
            parity ^= seam
            self.assertEqual(lane.process(opcode, seam=seam, mix=mix).output, opcode ^ parity ^ mix)


class FileAndArchitectureTests(unittest.TestCase):
    def test_writer_matches_in_memory_packer(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "raw.bin"
            result = write_bits(path, iter_word(25, limit=100001))
            expected = pack_bits(iter_word(25, limit=100001))
            self.assertEqual(path.read_bytes(), expected.data)
            self.assertEqual(result["bit_count"], expected.bit_count)
            self.assertEqual(result["sha256"], hashlib.sha256(expected.data).hexdigest())

    def test_empty_file_writer(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "empty.bin"
            result = write_bits(path, [], max_bits=0)
            self.assertEqual(path.read_bytes(), b"")
            self.assertEqual(result["bit_count"], 0)

    def test_writer_failure_keeps_existing_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "keep.bin"
            path.write_bytes(b"keep")
            for bad in ([1, 2], [0, 1, 0]):
                with self.assertRaises(ValueError):
                    write_bits(path, bad, max_bits=2)
                self.assertEqual(path.read_bytes(), b"keep")
                self.assertEqual(sorted(p.name for p in Path(tmp).iterdir()), ["keep.bin"])

    def test_cli_metadata_and_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = subprocess.run([sys.executable, "-m", "engine.demo", "--depth", "12",
                                  "--bits", "1000", "--output", tmp], cwd=ROOT,
                                 capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stderr)
            meta = json.loads((Path(tmp) / "stream.json").read_text())
            self.assertEqual(meta["payload"]["bit_count"], 233)
            self.assertEqual(meta["payload"]["byte_count"], 30)
            self.assertFalse(meta["truncated"])
            self.assertEqual(meta["sample_width_bits"], 1)
            self.assertIsNone(meta["clock_hz"])
            self.assertEqual((Path(tmp) / "grammar.bin").read_bytes(), pack_bits(iter_word(12)).data)

    def test_cli_prefix_and_zero(self):
        for limit in (0, 9):
            with tempfile.TemporaryDirectory() as tmp:
                run = subprocess.run([sys.executable, "-m", "engine.demo", "--bits", str(limit),
                                      "--output", tmp], cwd=ROOT, capture_output=True, text=True)
                self.assertEqual(run.returncode, 0, run.stderr)
                meta = json.loads((Path(tmp) / "stream.json").read_text())
                self.assertEqual(meta["payload"]["bit_count"], limit)
                self.assertTrue(meta["truncated"])

    def test_cli_bad_inputs(self):
        for args in (["--depth", "513"], ["--bits", "-1"], ["--seed", "2"],
                     ["--depth", "12", "--budget", "1"]):
            with tempfile.TemporaryDirectory() as tmp:
                run = subprocess.run([sys.executable, "-m", "engine.demo", *args, "--output", tmp],
                                     cwd=ROOT, capture_output=True, text=True)
                self.assertNotEqual(run.returncode, 0)
                self.assertFalse((Path(tmp) / "grammar.bin").exists())

    def test_production_python_has_no_float_path(self):
        for path in sorted((ROOT / "engine").glob("*.py")):
            tree = ast.parse(path.read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant):
                    self.assertNotIsInstance(node.value, (float, complex), (path, node.lineno))
                self.assertNotIsInstance(node, (ast.Div, ast.Pow), path)
                if isinstance(node, ast.Name):
                    self.assertNotIn(node.id, {"float", "complex", "Decimal", "Fraction"}, path)
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        self.assertNotIn(alias.name, {"math", "cmath", "numpy", "wave"}, path)
                if isinstance(node, ast.ImportFrom):
                    self.assertNotIn(node.module, {"math", "cmath", "numpy", "wave"}, path)

    def test_production_c_has_no_float_types_or_math_header(self):
        import re
        for path in (ROOT / "c").glob("*.[ch]"):
            text = re.sub(r"/\*.*?\*/", "", path.read_text(), flags=re.S)
            self.assertIsNone(re.search(r"\b(float|double)\b|<math\.h>", text), path)

    def test_no_coordinate_or_pcm_modules(self):
        import engine.core as core
        for name in ("trace_word", "sphere_sdf", "sigma_delta", "log_polar", "advance_phase"):
            self.assertFalse(hasattr(core, name), name)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import unittest

from engine import iter_word, pack_bits

ROOT = Path(__file__).resolve().parents[1]


class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shlex.split(os.environ.get("CC", "cc"))
        if not compiler or shutil.which(compiler[0]) is None:
            raise unittest.SkipTest("C99 compiler not available; Python tests remain runnable")
        cls.temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.temp.cleanup)
        cls.build = Path(cls.temp.name)
        cls.binary = cls.build / "tk1bit"
        cls.selftest = cls.build / "selftest"
        flags = ["-std=c99", "-O2", "-Wall", "-Wextra", "-Werror", "-pedantic"]
        for source, out in (("main.c", cls.binary), ("selftest.c", cls.selftest)):
            run = subprocess.run([*compiler, *flags, str(ROOT / "c/tk1bit.c"),
                                  str(ROOT / "c" / source), "-o", str(out)], capture_output=True, text=True)
            if run.returncode:
                raise AssertionError(f"C compilation failed:\n{run.stdout}\n{run.stderr}")

    def native(self, depth, limit, seed=0):
        path = self.build / "stream.bin"
        run = subprocess.run([str(self.binary), str(depth), str(limit), str(path), str(seed)],
                             capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        meta = json.loads(Path(str(path) + ".json").read_text())
        return path.read_bytes(), meta

    def test_native_selftest(self):
        run = subprocess.run([str(self.selftest)], capture_output=True, text=True)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("PASS:", run.stdout)

    def test_cross_language_complete_small_generations(self):
        for depth in range(22):
            for seed in (0, 1):
                with self.subTest(depth=depth, seed=seed):
                    raw, meta = self.native(depth, 100000, seed)
                    expected = pack_bits(iter_word(depth, str(seed)))
                    self.assertEqual(raw, expected.data)
                    self.assertEqual(meta["bit_count"], expected.bit_count)
                    self.assertEqual(meta["byte_count"], len(expected.data))

    def test_cross_language_deep_prefixes(self):
        for depth in (31, 32, 63, 64, 65, 127, 128, 255, 256, 511, 512):
            for seed in (0, 1):
                with self.subTest(depth=depth, seed=seed):
                    raw, meta = self.native(depth, 8193, seed)
                    expected = pack_bits(iter_word(depth, str(seed), limit=8193))
                    self.assertEqual(raw, expected.data)
                    self.assertEqual(meta["bit_count"], 8193)

    def test_cross_language_partial_bytes(self):
        for count in (0, 1, 2, 7, 8, 9, 15, 16, 17, 232, 233, 234, 4095, 4096, 4097):
            with self.subTest(count=count):
                raw, meta = self.native(24, count)
                self.assertEqual(raw, pack_bits(iter_word(24, limit=count)).data)
                self.assertEqual(meta["bit_count"], count)

    def test_native_invalid_arguments(self):
        for depth, limit, seed in ((-1, 10, 0), (513, 10, 0), (2, -1, 0), (2, 10, 2),
                                   ("1.5", 10, 0), (2, "x", 0), (2, "18446744073709551616", 0)):
            run = subprocess.run([str(self.binary), str(depth), str(limit),
                                  str(self.build / "bad.bin"), str(seed)], capture_output=True, text=True)
            self.assertNotEqual(run.returncode, 0)

    def test_native_missing_output_directory(self):
        run = subprocess.run([str(self.binary), "12", "1000", str(self.build / "missing/raw.bin")],
                             capture_output=True, text=True)
        self.assertNotEqual(run.returncode, 0)


if __name__ == "__main__":
    unittest.main()

# From the previous kernel to B1

The previous delivery used floating-point chart coordinates, headings,
procedural scalar fields and a synthesized reference waveform, with a separate
one-bit quantizer. That did not satisfy an end-to-end binary-symbol data path.
B1 replaces that architecture rather than repackaging it.

| Earlier P0 component | B1 replacement or status |
|---|---|
| String/host-symbol grammar | Packed pending grammar symbols and streamed terminal bits |
| Source productions `0 -> 1`, `1 -> 01` | Retained exactly, in the same production order |
| Coordinate-search/tree proposal | Not used; production traversal only enumerates grammar |
| Float heading and chart motion | Removed; one-bit step/turn event lanes |
| Golden-ratio numeric angle | Not evaluated; Fibonacci structure remains in the grammar |
| Numeric Klein chart and orientation label | Removed; an explicit seam input controls one orientation bit |
| Scalar SDF, cone, interval and polynomial blend | Removed, not redefined as Boolean operations |
| Float reference audio and PCM WAV | Removed |
| Float-input sigma-delta quantizer | Removed; already-binary events do not pass through amplitude quantization |
| Binary packing at the end of a numerical pipeline | One-bit symbols throughout the signal path; packed transport |
| Python-only reference | Python and independently compiled C99 implementations |

## API changes

`iter_word(depth, seed=0, count=..., budget=...)` uses a single seed bit rather
than a text axiom. Count means exactly that many events of a finite generation;
requesting more than that generation contains is an error. The count does not
repeat the generation or create a fixed infinite word.

`pack_bits` returns a `PackedBits(data, bit_count)` object. `unpack_bits` yields
an iterator and validates canonical byte length and padding. The old return
shape is not retained as a compatibility alias.

`Kernel.step` returns six binary-valued event fields instead of a numerical
`TraceEvent`. `run` executes an opcode stream with optional seam bits.
`RewriteStage` provides the serial cell/cycle model.

This is an intentional semantic change: numerical positions, field values,
pitch curves and reference sound files are no longer computed. The event
stream is usable as a compact symbolic driver, but the removed quantities
cannot be recovered by simply renaming its bits as coordinates or sound.

## Source versus additions

The source supplies the binary alphabet, production order, step/turn framing,
no-float output direction and the conceptual phase-inversion idea. B1 supplies
explicit stream framing, defaults, bounds, the ready/valid cell, seam-event API,
XOR ordering, tests and C/Python implementations. The source does not uniquely
define the complete geometric or hardware execution map. See `docs/SOURCE_MAP.md`.

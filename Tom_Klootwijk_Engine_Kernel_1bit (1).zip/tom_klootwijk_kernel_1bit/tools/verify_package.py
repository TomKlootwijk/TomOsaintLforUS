"""Check package bytes against SHA256SUMS.json; this is not a digital signature."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true", help="also report unexpected files")
    args = parser.parse_args()
    manifest = ROOT / "SHA256SUMS.json"
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        if data["algorithm"] != "SHA-256":
            raise ValueError("unsupported digest algorithm")
        entries = data["files"]
        if not isinstance(entries, dict):
            raise ValueError("files must be a mapping")
    except (OSError, ValueError, KeyError) as exc:
        print(f"Cannot read manifest: {exc}")
        return 1
    errors = []
    for name, expected in entries.items():
        rel = PurePosixPath(name)
        if rel.is_absolute() or ".." in rel.parts or "\\" in name:
            errors.append(f"unsafe manifest path: {name}")
            continue
        path = ROOT.joinpath(*rel.parts)
        try:
            if path.is_symlink() or ROOT not in path.resolve().parents:
                raise ValueError("symlink or path outside package")
            payload = path.read_bytes()
            if len(payload) != expected["bytes"]:
                errors.append(f"size mismatch: {name}")
            elif hashlib.sha256(payload).hexdigest() != expected["sha256"]:
                errors.append(f"hash mismatch: {name}")
        except (OSError, KeyError, TypeError, ValueError) as exc:
            errors.append(f"cannot verify {name}: {exc}")
    if args.strict:
        actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*")
                  if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}
        extras = actual - set(entries) - {"SHA256SUMS.json"}
        errors.extend(f"unexpected file: {name}" for name in sorted(extras))
    for error in errors:
        print(error)
    if errors:
        return 1
    print(f"Verified {len(entries)} delivered files (SHA-256 and byte length).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

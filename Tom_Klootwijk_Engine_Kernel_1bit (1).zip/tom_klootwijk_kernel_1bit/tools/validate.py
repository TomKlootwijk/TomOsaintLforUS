"""Run the delivered verification suite and record actual results locally."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("validation_local"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(ROOT))
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with (args.output / "test_results.txt").open("w", encoding="utf-8") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    compiler_path = shutil.which(os.environ.get("CC", "cc"))
    compiler_version = None
    if compiler_path:
        version = subprocess.run([compiler_path, "--version"], capture_output=True, text=True)
        if version.returncode == 0:
            compiler_version = version.stdout.splitlines()[0]
    report = {
        "profile": "B1", "version": "0.2.0",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "system": platform.platform(),
        "compiler": compiler_version,
        "tests_run": result.testsRun,
        "passed": result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
        "failures": len(result.failures), "errors": len(result.errors),
        "skipped": len(result.skipped),
        "skipped_details": [{"test": str(test), "reason": reason} for test, reason in result.skipped],
        "successful": result.wasSuccessful(),
        "native_tests_executed": bool(compiler_path) and not result.errors,
        "cell_cross_language_state_input_combinations": 512 if compiler_path and result.wasSuccessful() else None,
        "signal_representation": "one-bit symbols and Boolean lanes; multi-bit host control metadata",
        "source_audit": "Python AST and C source checks are included in the executed tests",
        "not_validated": ["hardware synthesis", "hardware timing", "physical propagation",
                          "metric seam detection", "analog reconstruction", "acoustic focusing"],
        "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for folder in ("engine", "c", "tests")
                          for p in sorted((ROOT / folder).glob("*")) if p.suffix in (".py", ".c", ".h")},
    }
    (args.output / "VALIDATION.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"{report['passed']}/{report['tests_run']} passed; "
          f"{report['failures']} failures; {report['errors']} errors; {report['skipped']} skipped.")
    print(f"Wrote validation records to {args.output}")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())

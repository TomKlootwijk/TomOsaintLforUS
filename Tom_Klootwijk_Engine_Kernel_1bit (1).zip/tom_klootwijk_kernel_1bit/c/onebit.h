#ifndef TK_ONEBIT_H
#define TK_ONEBIT_H
/* Portable C99 B1 reference. No heap, floating point, or amplitude DSP.
 * uint8_t API values must be 0 or 1. Lengths/depths are control metadata.
 * Bitfield allocation size is compiler-dependent, not a one-bit host CPU. */
#include <stddef.h>
#include <stdint.h>

#define TK1_MAX_DEPTH 512u
#define TK1_STACK_CAPACITY (TK1_MAX_DEPTH + 1u)
#define TK1_SYMBOL_BYTES ((TK1_STACK_CAPACITY + 7u) / 8u)
#define TK1_OK 0
#define TK1_END 1
#define TK1_INVALID (-1)

typedef struct {
    uint8_t symbols[TK1_SYMBOL_BYTES]; /* Packed pending grammar symbols. */
    uint16_t depths[TK1_STACK_CAPACITY]; /* Control, not signal samples. */
    size_t sp;
} tk1_word;

int tk1_word_init(tk1_word *word, unsigned depth, unsigned seed);
int tk1_word_next(tk1_word *word, uint8_t *out_bit);

typedef struct { unsigned orientation : 1; } tk1_kernel;
typedef struct {
    unsigned opcode : 1;
    unsigned step : 1;
    unsigned turn : 1;
    unsigned seam : 1;
    unsigned orientation : 1;
    unsigned output : 1;
} tk1_event;

int tk1_kernel_init(tk1_kernel *kernel, unsigned orientation);
int tk1_kernel_step(tk1_kernel *kernel, unsigned opcode, unsigned seam,
                    tk1_event *event);

/* One serial rewrite cell: four one-bit state flags, no depth counter. */
typedef struct {
    unsigned busy : 1;
    unsigned data : 1;
    unsigned tail : 1;
    unsigned last : 1;
} tk1_stage;
typedef struct {
    unsigned in_ready : 1;
    unsigned out_valid : 1;
    unsigned out_bit : 1;
    unsigned out_last : 1;
} tk1_signals;
void tk1_stage_init(tk1_stage *stage);
/* Returns PRE-edge signals, then updates state. reset is synchronous. */
int tk1_stage_tick(tk1_stage *stage, unsigned in_valid, unsigned in_bit,
                   unsigned in_last, unsigned out_ready, unsigned reset,
                   tk1_signals *signals);
#endif

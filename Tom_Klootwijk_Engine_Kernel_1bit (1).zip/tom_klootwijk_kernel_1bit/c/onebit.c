#include "onebit.h"
#include <string.h>

static void push(tk1_word *word, unsigned symbol, unsigned depth)
{
    size_t index = word->sp;
    uint8_t mask = (uint8_t)(1u << (7u - (unsigned)(index & 7u)));
    word->symbols[index >> 3u] &= (uint8_t)~mask;
    if (symbol) word->symbols[index >> 3u] |= mask;
    word->depths[index] = (uint16_t)depth;
    word->sp++;
}

int tk1_word_init(tk1_word *word, unsigned depth, unsigned seed)
{
    if (!word || depth > TK1_MAX_DEPTH || seed > 1u) return TK1_INVALID;
    memset(word, 0, sizeof(*word));
    push(word, seed, depth);
    return TK1_OK;
}

int tk1_word_next(tk1_word *word, uint8_t *out_bit)
{
    if (!word || !out_bit || word->sp > TK1_STACK_CAPACITY) return TK1_INVALID;
    while (word->sp) {
        size_t index;
        unsigned symbol, depth;
        word->sp--;
        index = word->sp;
        symbol = (word->symbols[index >> 3u] >> (7u - (unsigned)(index & 7u))) & 1u;
        depth = word->depths[index];
        if (depth > TK1_MAX_DEPTH) return TK1_INVALID;
        if (!depth) {
            *out_bit = (uint8_t)symbol;
            return TK1_OK;
        }
        if (word->sp + (symbol ? 2u : 1u) > TK1_STACK_CAPACITY) return TK1_INVALID;
        push(word, 1u, depth - 1u);
        if (symbol) push(word, 0u, depth - 1u);
    }
    return TK1_END;
}

int tk1_kernel_init(tk1_kernel *kernel, unsigned orientation)
{
    if (!kernel || orientation > 1u) return TK1_INVALID;
    kernel->orientation = orientation;
    return TK1_OK;
}

int tk1_kernel_step(tk1_kernel *kernel, unsigned opcode, unsigned seam,
                    tk1_event *event)
{
    if (!kernel || !event || opcode > 1u || seam > 1u) return TK1_INVALID;
    kernel->orientation ^= seam;
    event->opcode = opcode;
    event->step = opcode ^ 1u;
    event->turn = opcode;
    event->seam = seam;
    event->orientation = kernel->orientation;
    event->output = opcode ^ kernel->orientation;
    return TK1_OK;
}

void tk1_stage_init(tk1_stage *stage)
{
    if (stage) memset(stage, 0, sizeof(*stage));
}

int tk1_stage_tick(tk1_stage *stage, unsigned in_valid, unsigned in_bit,
                   unsigned in_last, unsigned out_ready, unsigned reset,
                   tk1_signals *signals)
{
    if (!stage || !signals || in_valid > 1u || in_bit > 1u || in_last > 1u ||
        out_ready > 1u || reset > 1u) return TK1_INVALID;
    signals->in_ready = (stage->busy ^ 1u) & (reset ^ 1u);
    signals->out_valid = stage->busy & (reset ^ 1u);
    signals->out_bit = stage->data;
    signals->out_last = stage->last & (stage->tail ^ 1u);
    if (reset) {
        tk1_stage_init(stage);
    } else if (stage->busy) {
        if (out_ready) {
            if (stage->tail) {
                stage->data = 1u;
                stage->tail = 0u;
            } else {
                stage->busy = 0u;
            }
        }
    } else if (in_valid) {
        stage->busy = 1u;
        stage->data = in_bit ^ 1u;
        stage->tail = in_bit;
        stage->last = in_last;
    }
    return TK1_OK;
}

#include "onebit.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    const char *words[] = {"0", "1", "01", "101", "01101", "10101101"};
    unsigned d, o, b, seam;
    for (d = 0; d < sizeof(words) / sizeof(words[0]); d++) {
        tk1_word word;
        size_t i;
        uint8_t value = 0;
        assert(tk1_word_init(&word, d, 0) == TK1_OK);
        for (i = 0; i < strlen(words[d]); i++) {
            assert(tk1_word_next(&word, &value) == TK1_OK);
            assert(value == (uint8_t)(words[d][i] - '0'));
        }
        assert(tk1_word_next(&word, &value) == TK1_END);
        assert(tk1_word_next(&word, &value) == TK1_END);
    }
    for (o = 0; o < 2; o++) for (b = 0; b < 2; b++) for (seam = 0; seam < 2; seam++) {
        tk1_kernel kernel;
        tk1_event event;
        assert(tk1_kernel_init(&kernel, o) == TK1_OK);
        assert(tk1_kernel_step(&kernel, b, seam, &event) == TK1_OK);
        assert(event.output == (b ^ o ^ seam));
        assert(event.orientation == (o ^ seam));
        assert(event.step == (b ^ 1u));
        assert(event.turn == b);
        assert(tk1_kernel_step(&kernel, 2, 0, &event) == TK1_INVALID);
        assert(kernel.orientation == (o ^ seam));
    }
    {
        tk1_stage stage;
        tk1_signals ports;
        tk1_stage_init(&stage);
        assert(tk1_stage_tick(&stage, 1, 1, 1, 1, 0, &ports) == TK1_OK);
        assert(ports.in_ready && !ports.out_valid);
        assert(tk1_stage_tick(&stage, 0, 0, 0, 0, 0, &ports) == TK1_OK);
        assert(ports.out_valid && !ports.out_bit && !ports.out_last);
        assert(tk1_stage_tick(&stage, 0, 0, 0, 1, 0, &ports) == TK1_OK);
        assert(ports.out_valid && !ports.out_bit && !ports.out_last);
        assert(tk1_stage_tick(&stage, 0, 0, 0, 1, 0, &ports) == TK1_OK);
        assert(ports.out_valid && ports.out_bit && ports.out_last);
        assert(tk1_stage_tick(&stage, 0, 0, 0, 1, 0, &ports) == TK1_OK);
        assert(ports.in_ready && !ports.out_valid);
        assert(tk1_stage_tick(&stage, 1, 1, 1, 1, 1, &ports) == TK1_OK);
        assert(!ports.in_ready && !ports.out_valid && !stage.busy);
    }
    {
        tk1_word word;
        uint8_t value;
        unsigned i;
        assert(tk1_word_init(&word, TK1_MAX_DEPTH, 1) == TK1_OK);
        for (i = 0; i < 10000; i++) {
            assert(tk1_word_next(&word, &value) == TK1_OK);
            assert(value <= 1u);
        }
        assert(tk1_word_init(&word, TK1_MAX_DEPTH + 1, 0) == TK1_INVALID);
        assert(tk1_word_init(NULL, 0, 0) == TK1_INVALID);
        assert(tk1_word_next(NULL, &value) == TK1_INVALID);
    }
    puts("Native C99 assertions passed.");
    return 0;
}

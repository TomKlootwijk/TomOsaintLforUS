/* Native raw-grammar writer. Usage: onebit DEPTH COUNT OUTPUT.bin [SEED]
 * Creates OUTPUT.bin and OUTPUT.bin.json; outputs contain no timing or PCM.
 * Unlike the Python CLI, this small POSIX-oriented demo overwrites its paths.
 * The portable kernel itself has no filesystem dependencies. */
#include "onebit.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int parse_number(const char *text, uint64_t *value)
{
    char *end = NULL;
    unsigned long long parsed;
    if (!text || !*text || strspn(text, "0123456789") != strlen(text)) return 0;
    errno = 0;
    parsed = strtoull(text, &end, 10);
    if (errno || !end || *end || parsed > UINT64_MAX) return 0;
    *value = (uint64_t)parsed;
    return 1;
}

int main(int argc, char **argv)
{
    tk1_word word;
    uint64_t depth, count, seed = 0, index;
    unsigned packed = 0, used = 0;
    FILE *stream;
    char *meta_name;
    if ((argc != 4 && argc != 5) || !parse_number(argv[1], &depth) ||
        !parse_number(argv[2], &count) ||
        (argc == 5 && !parse_number(argv[4], &seed)) ||
        depth > TK1_MAX_DEPTH || seed > 1u || count > 1000000u) {
        fprintf(stderr, "Usage: onebit DEPTH(0..512) COUNT(0..1000000) OUTPUT.bin [SEED(0|1)]\n");
        return 2;
    }
    if (tk1_word_init(&word, (unsigned)depth, (unsigned)seed) != TK1_OK) return 2;
    stream = fopen(argv[3], "wb");
    if (!stream) { perror("output"); return 1; }
    for (index = 0; index < count; index++) {
        uint8_t value;
        if (tk1_word_next(&word, &value) != TK1_OK) {
            fprintf(stderr, "Requested count exceeds finite generation; incomplete output removed.\n");
            fclose(stream); remove(argv[3]); return 2;
        }
        packed |= (unsigned)value << (7u - used);
        used++;
        if (used == 8u) {
            if (fputc((int)packed, stream) == EOF) {
                fclose(stream); remove(argv[3]); return 1;
            }
            packed = 0; used = 0;
        }
    }
    if (used && fputc((int)packed, stream) == EOF) {
        fclose(stream); remove(argv[3]); return 1;
    }
    if (fclose(stream)) { remove(argv[3]); return 1; }
    meta_name = malloc(strlen(argv[3]) + sizeof(".json"));
    if (!meta_name) return 1;
    strcpy(meta_name, argv[3]); strcat(meta_name, ".json");
    stream = fopen(meta_name, "w");
    free(meta_name);
    if (!stream) return 1;
    if (fprintf(stream,
        "{\n  \"format\": \"TK-B1-RAW/1\",\n  \"kind\": \"grammar\",\n"
        "  \"packing\": \"MSB-first; zero low-bit padding\",\n"
        "  \"depth\": %" PRIu64 ",\n  \"seed\": %" PRIu64 ",\n"
        "  \"logical_bits\": %" PRIu64 ",\n  \"storage_bytes\": %" PRIu64 ",\n"
        "  \"padding_bits\": %u,\n  \"sample_rate\": null\n}\n",
        depth, seed, count, (count + 7u) / 8u,
        (8u - (unsigned)(count & 7u)) & 7u) < 0) {
        fclose(stream); return 1;
    }
    if (fclose(stream)) return 1;
    return 0;
}

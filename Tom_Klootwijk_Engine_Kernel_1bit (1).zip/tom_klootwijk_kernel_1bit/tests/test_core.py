import ast
import io
import itertools
from pathlib import Path
import random
import unittest

from engine.core import (BitWriter, Kernel, PackedBits, RewriteStage, _BitStack,
                         bit, iter_word, pack_bits, rewrite_once, run,
                         symbol_counts, unpack_bits, write_bits)


class GrammarTests(unittest.TestCase):
    def test_source_production_order(self):
        self.assertEqual(list(rewrite_once([0, 1])), [1, 0, 1])

    def test_exact_seed_zero_generations(self):
        expected = ["0", "1", "01", "101", "01101", "10101101", "0110110101101"]
        for d, text in enumerate(expected):
            self.assertEqual("".join(map(str, iter_word(d))), text)

    def test_exact_seed_one_generations(self):
        for d in range(18):
            self.assertEqual(list(iter_word(d, 1)), list(iter_word(d + 1, 0)))

    def test_independent_parallel_rewrite(self):
        for seed in (0, 1):
            word = str(seed)
            for depth in range(18):
                self.assertEqual(list(iter_word(depth, seed)), [int(c) for c in word])
                word = "".join("1" if c == "0" else "01" for c in word)

    def test_counts_match_materialized_words(self):
        for seed in (0, 1):
            for depth in range(17):
                word = list(iter_word(depth, seed))
                self.assertEqual(symbol_counts(depth, seed), (word.count(0), word.count(1)))

    def test_finite_generation_not_assumed_fixed_prefix(self):
        self.assertNotEqual(next(iter_word(30, count=1)), next(iter_word(31, count=1)))

    def test_bounded_prefix_matches_full_word(self):
        word = list(iter_word(20))
        for length in (0, 1, 7, 8, 9, 233, 4097):
            self.assertEqual(list(iter_word(20, count=length)), word[:length])

    def test_maximum_depth_streaming_prefix(self):
        word = list(iter_word(512, count=10000))
        self.assertEqual(len(word), 10000)
        self.assertEqual(set(word), {0, 1})

    def test_empty_prefix(self):
        self.assertEqual(list(iter_word(512, count=0, budget=0)), [])

    def test_default_budget_rejects_unbounded_large_generation(self):
        with self.assertRaises(ValueError):
            list(iter_word(512))

    def test_explicit_budget(self):
        self.assertEqual(len(list(iter_word(20, count=64, budget=64))), 64)
        with self.assertRaises(ValueError):
            list(iter_word(20, count=65, budget=64))

    def test_count_past_end_is_error(self):
        with self.assertRaises(ValueError):
            list(iter_word(2, count=3))

    def test_invalid_control_inputs(self):
        for bad in (-1, 513, True, 1.5, "2"):
            with self.assertRaises(ValueError):
                list(iter_word(bad))
        for bad in (-1, True, 1.5, "2"):
            with self.assertRaises(ValueError):
                list(iter_word(4, count=bad))
        for bad in (-1, True, 1.5):
            with self.assertRaises(ValueError):
                list(iter_word(4, budget=bad))

    def test_invalid_alphabet_is_not_quantized(self):
        for bad in (-1, 2, True, 0.0, "0", None):
            with self.assertRaises(ValueError):
                list(rewrite_once([bad]))
            with self.assertRaises(ValueError):
                list(iter_word(0, bad))

    def test_packed_stack_across_byte_boundaries(self):
        stack = _BitStack()
        for n in range(1000):
            stack.push((n ^ (n >> 3)) & 1)
        self.assertEqual(len(stack._bytes), 125)
        for n in reversed(range(1000)):
            self.assertEqual(stack.pop(), (n ^ (n >> 3)) & 1)
        self.assertEqual(len(stack._bytes), 0)
        with self.assertRaises(IndexError):
            stack.pop()

    def test_packed_stack_reuses_partial_bytes(self):
        stack = _BitStack()
        stack.push(1); stack.push(1); stack.pop(); stack.push(0)
        self.assertEqual(stack.pop(), 0)
        self.assertEqual(stack.pop(), 1)


class PackingTests(unittest.TestCase):
    def test_known_msb_vector(self):
        packed = pack_bits([1, 0, 1, 1, 0, 0, 1, 0, 1])
        self.assertEqual(packed, PackedBits(bytes([0xB2, 0x80]), 9))

    def test_all_tail_lengths_roundtrip(self):
        rng = random.Random(197)
        for length in range(257):
            word = [rng.getrandbits(1) for _ in range(length)]
            packed = pack_bits(word)
            self.assertEqual(list(packed), word)
            self.assertEqual(len(packed.data), (length + 7) // 8)

    def test_empty_payload(self):
        self.assertEqual(pack_bits([]), PackedBits(b"", 0))

    def test_canonical_padding_required(self):
        with self.assertRaises(ValueError):
            PackedBits(b"\xa1", 3)

    def test_payload_length_required(self):
        for data, count in ((b"", 1), (b"\0\0", 1), (b"\0", 9), (b"\0", 0)):
            with self.assertRaises(ValueError):
                PackedBits(data, count)

    def test_payload_types_rejected(self):
        for data in (bytearray(b"\0"), "0", [0]):
            with self.assertRaises(ValueError):
                PackedBits(data, 8)
        for count in (-1, True, 1.5):
            with self.assertRaises(ValueError):
                PackedBits(b"\0", count)

    def test_unpack_iterator(self):
        self.assertEqual(list(unpack_bits(b"\xa0", 3)), [1, 0, 1])

    def test_reject_bad_symbols(self):
        for bad in (2, -1, 0.0, True):
            with self.assertRaises(ValueError):
                pack_bits([0, bad])

    def test_stream_writer_matches_pack_with_multiple_flushes(self):
        raw = io.BytesIO()
        count = write_bits(raw, iter_word(24, count=70001))
        expected = pack_bits(iter_word(24, count=70001))
        self.assertEqual(count, expected.bit_count)
        self.assertEqual(raw.getvalue(), expected.data)

    def test_writer_finish_and_closed_state(self):
        raw = io.BytesIO(); writer = BitWriter(raw)
        writer.write(1)
        self.assertEqual(writer.finish(), 1)
        self.assertEqual(writer.finish(), 1)
        self.assertEqual(raw.getvalue(), b"\x80")
        self.assertFalse(raw.closed)
        with self.assertRaises(ValueError):
            writer.write(0)

    def test_writer_handles_short_writes(self):
        class ShortWriter(io.BytesIO):
            def write(self, data):
                return super().write(data[:2])
        raw = ShortWriter()
        write_bits(raw, iter_word(15))
        self.assertEqual(raw.getvalue(), pack_bits(iter_word(15)).data)

    def test_writer_detects_failed_write(self):
        class BrokenWriter:
            def write(self, data):
                return 0
        with self.assertRaises(OSError):
            write_bits(BrokenWriter(), [1])


class KernelTests(unittest.TestCase):
    def test_truth_table(self):
        for orientation, opcode, seam in itertools.product((0, 1), repeat=3):
            kernel = Kernel(orientation)
            event = kernel.step(opcode, seam)
            self.assertEqual(event.opcode, opcode)
            self.assertEqual(event.step, opcode ^ 1)
            self.assertEqual(event.turn, opcode)
            self.assertEqual(event.orientation, orientation ^ seam)
            self.assertEqual(event.output, opcode ^ orientation ^ seam)

    def test_pure_binary_fields(self):
        for event in run(iter_word(20)):
            self.assertTrue(all(type(getattr(event, name)) is int and getattr(event, name) in (0, 1)
                                for name in event.__slots__))

    def test_no_seam_identity_output(self):
        word = list(iter_word(14))
        self.assertEqual([e.output for e in run(word)], word)

    def test_initial_orientation_inverts_output_only(self):
        word = list(iter_word(8))
        events = list(run(word, orientation=1))
        self.assertEqual([e.output for e in events], [b ^ 1 for b in word])
        self.assertEqual([e.opcode for e in events], word)

    def test_seam_is_applied_before_current_output(self):
        event = Kernel().step(0, 1)
        self.assertEqual((event.orientation, event.output), (1, 1))

    def test_two_seams_restore_orientation(self):
        kernel = Kernel()
        kernel.step(0, 1)
        event = kernel.step(0, 1)
        self.assertEqual((event.orientation, event.output), (0, 0))

    def test_seams_do_not_change_instruction_decoding(self):
        for opcode in (0, 1):
            a, b = Kernel().step(opcode, 0), Kernel().step(opcode, 1)
            self.assertEqual((a.step, a.turn), (b.step, b.turn))

    def test_reset(self):
        kernel = Kernel(1)
        kernel.reset()
        self.assertEqual(kernel.orientation, 0)
        kernel.reset(1)
        self.assertEqual(kernel.orientation, 1)

    def test_invalid_symbol_does_not_mutate_state(self):
        kernel = Kernel()
        for opcode, seam in ((2, 1), (0, 2), (0.0, 1), (1, True)):
            with self.assertRaises(ValueError):
                kernel.step(opcode, seam)
            self.assertEqual(kernel.orientation, 0)

    def test_invalid_initial_orientation(self):
        for bad in (-1, 2, True, 0.0):
            with self.assertRaises(ValueError):
                Kernel(bad)

    def test_short_seam_stream_is_error(self):
        with self.assertRaises(ValueError):
            list(run([0, 1], [0]))

    def test_long_seam_stream_is_error(self):
        with self.assertRaises(ValueError):
            list(run([0], [0, 1]))

    def test_empty_streams(self):
        self.assertEqual(list(run([], [])), [])
        self.assertEqual(list(run([])), [])

    def test_explicit_seam_trace(self):
        events = list(run([0, 1, 0, 1, 1], [0, 1, 0, 1, 0]))
        self.assertEqual([e.orientation for e in events], [0, 1, 1, 0, 0])
        self.assertEqual([e.output for e in events], [0, 0, 1, 1, 1])


class RewriteCellTests(unittest.TestCase):
    @staticmethod
    def simulate(depth, source, ready_pattern=(1,)):
        if depth == 0:
            return source
        stages = [RewriteStage() for _ in range(depth)]
        index = 0; received = []
        # Generous finite bound for the small verification cases.
        for cycle in range(200000):
            ports = [s.signals() for s in stages]
            ready = ready_pattern[cycle % len(ready_pattern)]
            if ports[-1].out_valid and ready:
                received.append((ports[-1].out_bit, ports[-1].out_last))
            input_valid = int(index < len(source))
            value, last = source[index] if input_valid else (0, 0)
            accepted = input_valid and ports[0].in_ready
            for pos, stage in enumerate(stages):
                incoming = (input_valid, value, last) if pos == 0 else (
                    ports[pos - 1].out_valid, ports[pos - 1].out_bit, ports[pos - 1].out_last)
                outgoing_ready = ready if pos == depth - 1 else ports[pos + 1].in_ready
                stage.tick(*incoming, out_ready=outgoing_ready)
            if accepted:
                index += 1
            if index == len(source) and all(s.busy == 0 for s in stages):
                return received
        raise AssertionError("serial stage simulation did not terminate")

    def test_zero_production(self):
        self.assertEqual(self.simulate(1, [(0, 1)]), [(1, 1)])

    def test_one_production(self):
        self.assertEqual(self.simulate(1, [(1, 1)]), [(0, 0), (1, 1)])

    def test_two_frames_keep_last_boundaries(self):
        self.assertEqual(self.simulate(1, [(1, 1), (0, 1)]), [(0, 0), (1, 1), (1, 1)])

    def test_cascade_matches_finite_grammar_under_backpressure(self):
        for depth in range(1, 11):
            for seed in (0, 1):
                result = self.simulate(depth, [(seed, 1)], (1, 0, 0, 1, 1, 0, 1))
                self.assertEqual([b for b, _ in result], list(iter_word(depth, seed)))
                self.assertEqual([last for _, last in result], [0] * (len(result) - 1) + [1])

    def test_multi_symbol_seed_frames(self):
        source = [(1, 0), (0, 1), (1, 1)]
        for depth in range(1, 7):
            result = self.simulate(depth, source, (0, 1, 1))
            expected = []
            for seed, last in source:
                word = list(iter_word(depth, seed))
                expected += [(b, last if i == len(word) - 1 else 0) for i, b in enumerate(word)]
            self.assertEqual(result, expected)

    def test_output_is_stable_while_stalled(self):
        stage = RewriteStage(); stage.tick(1, 1, 1, 0)
        before = stage.signals()
        for _ in range(20):
            self.assertEqual(stage.tick(1, 0, 0, 0), before)
        self.assertEqual(stage.signals(), before)

    def test_synchronous_reset_discards_pending_symbol(self):
        stage = RewriteStage(); stage.tick(1, 1, 1, 0)
        ports = stage.tick(1, 1, 1, 1, reset=1)
        self.assertEqual((ports.in_ready, ports.out_valid), (0, 0))
        self.assertEqual((stage.busy, stage.data, stage.tail, stage.last), (0, 0, 0, 0))

    def test_invalid_stage_input(self):
        stage = RewriteStage()
        for kwargs in ({"in_bit": 2}, {"in_valid": True}, {"out_ready": -1}, {"reset": 0.0}):
            with self.assertRaises(ValueError):
                stage.tick(**kwargs)

    def test_stage_state_is_four_bits(self):
        self.assertEqual(RewriteStage.__slots__, ("busy", "data", "tail", "last"))
        stage = RewriteStage()
        for mask in range(32):
            stage.tick(*[(mask >> k) & 1 for k in range(5)])
            self.assertTrue(all(getattr(stage, key) in (0, 1) for key in stage.__slots__))


class BinarySourceAuditTests(unittest.TestCase):
    def test_core_has_no_floating_literals_or_true_division(self):
        source = Path(__file__).resolve().parents[1] / "engine" / "core.py"
        tree = ast.parse(source.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant):
                self.assertNotIsInstance(node.value, (float, complex))
            self.assertNotIsInstance(node, ast.Div)

    def test_core_has_no_numeric_dsp_imports_or_conversions(self):
        source = Path(__file__).resolve().parents[1] / "engine" / "core.py"
        tree = ast.parse(source.read_text())
        forbidden = {"float", "complex", "Decimal", "Fraction", "math", "cmath", "numpy", "scipy"}
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                self.assertNotIn(node.id, forbidden)
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    self.assertNotIn(alias.name.split(".")[0], forbidden)


if __name__ == "__main__":
    unittest.main()

/* Test adapter: packs separate Boolean state/port flags into an integer solely
 * so Python ctypes can compare them without depending on C bitfield layout. */
#include "onebit.h"

unsigned bridge_stage(unsigned state, unsigned inputs)
{
    tk1_stage s;
    tk1_signals p;
    s.busy = state & 1u;
    s.data = (state >> 1u) & 1u;
    s.tail = (state >> 2u) & 1u;
    s.last = (state >> 3u) & 1u;
    if (tk1_stage_tick(&s, inputs & 1u, (inputs >> 1u) & 1u,
                      (inputs >> 2u) & 1u, (inputs >> 3u) & 1u,
                      (inputs >> 4u) & 1u, &p) != TK1_OK) return 65535u;
    return s.busy | (s.data << 1u) | (s.tail << 2u) | (s.last << 3u) |
           (p.in_ready << 4u) | (p.out_valid << 5u) |
           (p.out_bit << 6u) | (p.out_last << 7u);
}

unsigned bridge_kernel(unsigned orientation, unsigned opcode, unsigned seam)
{
    tk1_kernel k;
    tk1_event e;
    if (tk1_kernel_init(&k, orientation) != TK1_OK ||
        tk1_kernel_step(&k, opcode, seam, &e) != TK1_OK) return 65535u;
    return e.opcode | (e.step << 1u) | (e.turn << 2u) | (e.seam << 3u) |
           (e.orientation << 4u) | (e.output << 5u);
}

int bridge_word(unsigned depth, unsigned seed, uint8_t *out, unsigned count)
{
    tk1_word word;
    unsigned i;
    int status = tk1_word_init(&word, depth, seed);
    if (status != TK1_OK) return status;
    for (i = 0; i < count; i++) {
        status = tk1_word_next(&word, &out[i]);
        if (status != TK1_OK) return status;
    }
    return TK1_OK;
}

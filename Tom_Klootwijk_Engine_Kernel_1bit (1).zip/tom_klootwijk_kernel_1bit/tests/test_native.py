import ctypes
import itertools
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest
from engine.core import Kernel, RewriteStage, iter_word, pack_bits, symbol_counts

ROOT = Path(__file__).resolve().parents[1]
CC = shutil.which(os.environ.get("CC", "cc"))

@unittest.skipUnless(CC, "C compiler unavailable; native tests not executed")
class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.build = Path(cls.temp.name)
        flags = [CC, "-std=c99", "-O2", "-Wall", "-Wextra", "-Werror", "-pedantic", "-I", str(ROOT / "c")]
        for source, output, extra in (
            (ROOT / "tests" / "native_bridge.c", cls.build / "libonebit.so", ["-fPIC", "-shared"]),
            (ROOT / "c" / "demo.c", cls.build / "onebit", []),
            (ROOT / "c" / "test_onebit.c", cls.build / "native_test", []),
        ):
            result = subprocess.run(flags + extra + [str(ROOT / "c" / "onebit.c"), str(source), "-o", str(output)],
                                    capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
        cls.lib = ctypes.CDLL(str(cls.build / "libonebit.so"))
        cls.lib.bridge_stage.argtypes = [ctypes.c_uint, ctypes.c_uint]
        cls.lib.bridge_stage.restype = ctypes.c_uint
        cls.lib.bridge_kernel.argtypes = [ctypes.c_uint] * 3
        cls.lib.bridge_kernel.restype = ctypes.c_uint
        cls.lib.bridge_word.argtypes = [ctypes.c_uint, ctypes.c_uint,
                                       ctypes.POINTER(ctypes.c_uint8), ctypes.c_uint]
        cls.lib.bridge_word.restype = ctypes.c_int

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_standalone_native_assertions(self):
        result = subprocess.run([str(self.build / "native_test")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("assertions passed", result.stdout)

    def test_all_512_cell_state_input_combinations_match_python(self):
        for state, inputs in itertools.product(range(16), range(32)):
            stage = RewriteStage()
            for pos, field in enumerate(stage.__slots__):
                setattr(stage, field, (state >> pos) & 1)
            ports = stage.tick(*[(inputs >> pos) & 1 for pos in range(5)])
            expected = sum(getattr(stage, field) << pos for pos, field in enumerate(stage.__slots__))
            expected |= sum(getattr(ports, field) << (4 + pos) for pos, field in enumerate(ports.__slots__))
            self.assertEqual(self.lib.bridge_stage(state, inputs), expected, (state, inputs))

    def test_native_interpreter_truth_table_matches_python(self):
        for o, b, seam in itertools.product((0, 1), repeat=3):
            event = Kernel(o).step(b, seam)
            packed = sum(getattr(event, field) << pos for pos, field in enumerate(event.__slots__))
            self.assertEqual(self.lib.bridge_kernel(o, b, seam), packed)

    def test_native_rejects_invalid_bits(self):
        for args in ((2, 0, 0), (0, 2, 0), (0, 0, 2)):
            self.assertEqual(self.lib.bridge_kernel(*args), 65535)

    def test_native_words_match_python_both_seeds(self):
        for seed in (0, 1):
            for depth in list(range(19)) + [40, 511, 512]:
                size = min(sum(symbol_counts(depth, seed)), 4097)
                array = (ctypes.c_uint8 * size)()
                self.assertEqual(self.lib.bridge_word(depth, seed, array, size), 0)
                self.assertEqual(list(array), list(iter_word(depth, seed, count=size)))

    def test_native_end_of_finite_word(self):
        array = (ctypes.c_uint8 * 3)()
        self.assertEqual(self.lib.bridge_word(2, 0, array, 3), 1)
        self.assertEqual(self.lib.bridge_word(513, 0, array, 1), -1)

    def test_native_binary_payloads_and_framing_match_python(self):
        for depth, count, seed in ((0, 1, 0), (5, 8, 0), (12, 233, 0),
                                   (24, 65536, 0), (512, 4097, 1), (24, 0, 0)):
            dest = self.build / f"payload-{depth}-{count}-{seed}.bin"
            result = subprocess.run([str(self.build / "onebit"), str(depth), str(count), str(dest), str(seed)],
                                    capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            expected = pack_bits(iter_word(depth, seed, count=count))
            self.assertEqual(dest.read_bytes(), expected.data)
            metadata = json.loads(Path(str(dest) + ".json").read_text())
            self.assertEqual(metadata["logical_bits"], count)
            self.assertEqual(metadata["storage_bytes"], len(expected.data))

    def test_native_cli_rejects_bad_inputs(self):
        dest = self.build / "invalid.bin"
        for depth, count in (("-1", "1"), ("2.5", "1"), ("513", "1"),
                             ("24", "1000001"), ("0", "2")):
            result = subprocess.run([str(self.build / "onebit"), depth, count, str(dest)],
                                    capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(dest.exists())

    def test_c_kernel_has_no_floating_point_types_or_math_library(self):
        for name in ("onebit.c", "onebit.h"):
            text = (ROOT / "c" / name).read_text()
            text = re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)
            self.assertIsNone(re.search(r"\b(float|double|_Complex)\b|math\.h", text))

if __name__ == "__main__":
    unittest.main()

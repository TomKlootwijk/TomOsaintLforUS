import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from engine.core import PackedBits, iter_word, pack_bits
from engine.demo import generate

ROOT = Path(__file__).resolve().parents[1]

class CliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_default_65536_bits_are_8192_bytes(self):
        report = generate(self.root / "output")
        self.assertEqual(report["emitted_bits"], 65536)
        for lane in report["streams"].values():
            self.assertEqual(lane["storage_bytes"], 8192)
            self.assertEqual(lane["padding_bits"], 0)

    def test_full_generation_exact_packing_and_metadata(self):
        dest = self.root / "out"
        report = generate(dest, depth=12, count=None)
        self.assertEqual(report["emitted_bits"], 233)
        self.assertFalse(report["is_prefix"])
        expected = pack_bits(iter_word(12))
        self.assertEqual((dest / "grammar.bin").read_bytes(), expected.data)
        self.assertEqual((dest / "phase.bin").read_bytes(), expected.data)
        for stream in report["streams"].values():
            payload = (dest / stream["file"]).read_bytes()
            self.assertEqual(hashlib.sha256(payload).hexdigest(), stream["sha256"])
            self.assertEqual(len(list(PackedBits(payload, stream["logical_bits"]))), 233)
            self.assertEqual(stream["padding_bits"], 7)

    def test_external_seams_and_onebit_lanes(self):
        dest = self.root / "out"
        report = generate(dest, depth=8, count=31, seam_at=(0, 7, 17))
        lanes = {name: list(PackedBits((dest / data["file"]).read_bytes(), 31))
                 for name, data in report["streams"].items()}
        orientation = 0
        for i, opcode in enumerate(lanes["grammar"]):
            seam = int(i in (0, 7, 17)); orientation ^= seam
            self.assertEqual(lanes["seams"][i], seam)
            self.assertEqual(lanes["orientation"][i], orientation)
            self.assertEqual(lanes["phase"][i], opcode ^ orientation)
            self.assertEqual(lanes["step"][i], opcode ^ 1)
            self.assertEqual(lanes["turn"][i], opcode)

    def test_zero_count_produces_zero_byte_lanes(self):
        report = generate(self.root / "out", count=0)
        self.assertEqual(report["emitted_bits"], 0)
        self.assertTrue(all(d["storage_bytes"] == 0 for d in report["streams"].values()))

    def test_invalid_input_does_not_create_output(self):
        dest = self.root / "out"
        for kwargs in ({"depth": -1}, {"depth": 0, "count": 2}, {"count": -1},
                       {"seam_at": (65536,)}, {"seam_at": (3, 3)}, {"orientation": 2}):
            with self.assertRaises(ValueError):
                generate(dest, **kwargs)
            self.assertFalse(dest.exists())

    def test_existing_delivered_files_are_not_overwritten(self):
        dest = self.root / "out"
        generate(dest, depth=2, count=2)
        with self.assertRaises(ValueError):
            generate(dest, depth=3, count=3)

    def test_python_module_entrypoint(self):
        dest = self.root / "out"
        result = subprocess.run([sys.executable, "-m", "engine", "--depth", "12", "--full",
                                 "--output", str(dest)], cwd=ROOT, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads((dest / "metadata.json").read_text())["emitted_bits"], 233)

    def test_cli_error_exit(self):
        result = subprocess.run([sys.executable, "-m", "engine", "--depth", "0", "--count", "2",
                                 "--output", str(self.root / "out")],
                                cwd=ROOT, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("exceeds", result.stderr)
        self.assertFalse((self.root / "out").exists())

    def test_no_wav_or_multibit_sample_file(self):
        dest = self.root / "out"
        generate(dest, depth=2, count=2)
        self.assertEqual({p.suffix for p in dest.iterdir()}, {".json", ".bin"})

if __name__ == "__main__":
    unittest.main()

# Tom Klootwijk — 1-bit engine kernel

**B1 profile · version 0.2.0 · Python reference + portable C99 kernel**

This revision replaces the previous floating-point kernel with **binary-symbol
execution from grammar to output**. It is not the old numerical engine with a
one-bit quantizer attached at the end. There are no floating-point or fixed-point
coordinates, amplitude samples, trigonometric calls, PCM files, or WAV output in
this implementation.

The source productions are preserved exactly:

```text
0 -> 1
1 -> 01
```

Each terminal opcode is one bit: `0` requests a step/time advance; `1` requests a
symbolic turn/branch. A one-bit seam input can toggle a persistent orientation
bit. The phase-output bit is the opcode XOR the updated orientation. With no
seams and initial orientation zero, the output is exactly the grammar stream.

**Scope:** this is a binary symbolic execution kernel. The old numerical
geometry and signal-generation functions are removed, not secretly replaced by
fixed-point versions. Step/turn requests do not themselves compute a distance,
rotation angle, physical wavefront, or branch geometry. The source does not
supply the complete bit-level geometric mapping needed to do that uniquely.

## Run immediately — Python

Python 3.10 or newer; standard library only. Tested in the delivered validation
run with Python 3.13.5 on Linux. No installation, account, network, or hardware
access is needed. The commands write files; they do not play sound.

From the extracted `tom_klootwijk_kernel_1bit` directory:

```sh
# Run Python and C cross-checks. Native checks need a C compiler.
python -m unittest discover -s tests -v

# Emit a 65,536-bit prefix of finite generation 24.
python -m engine --depth 24 --count 65536 --output run_output

# A complete smaller generation: 233 logical bits, stored in 30 bytes.
python -m engine --depth 12 --full --output generation_12

# Verify the delivered source, examples and validation records.
python tools/verify_package.py
```

Use `python3` where that is the Python 3 command. There are no pip dependencies.
The Python CLI refuses to overwrite previously generated filenames. A `--count`
larger than the selected finite generation is an error, not an implicit repeat.

## Native C99

The C kernel uses no heap allocation and has no dependency on the Python
runtime, filesystem, mathematics library, audio framework, or device drivers.
The small command-line example does use ordinary file I/O and an allocated
metadata filename; that is outside the kernel.

```sh
make native-test
make
./build/onebit 24 65536 native_grammar.bin
```

Without `make`:

```sh
cc -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I c \
  c/onebit.c c/demo.c -o onebit
./onebit 24 65536 native_grammar.bin
```

Arguments: `DEPTH COUNT OUTPUT.bin [SEED]`. The native example emits the raw
grammar lane and `OUTPUT.bin.json` framing metadata. Unlike the Python CLI, this
minimal example overwrites those paths. Use new output filenames. The kernel's
C API also exposes orientation/XOR execution and the serial rewrite cell.

## What “1-bit” means in this delivery

| Layer | Representation |
|---|---|
| Instruction alphabet | Exactly `0` or `1`; no amplitude-to-bit conversion |
| Grammar storage | Pending symbols packed into bits; no expanded word required |
| Symbolic interpreter | One persistent orientation bit; Boolean step/turn/phase lanes |
| Serial rewrite cell | Four one-bit flags; input and output each carry one bit |
| Materialized streams | Eight logical symbols per full byte; MSB-first |
| Host control | Multi-bit depths, indexes, byte buffers, lengths and budgets |

One-bit data does **not** mean the whole program, its host processor, or all
memory consists of a single bit. Python represents individual Boolean-valued
signals with host integer objects. C transports individual bits through byte
arguments and uses one-bit fields for the serial/interpreter state; C bitfield
allocation size is compiler-dependent. Neither implementation performs
multi-bit amplitude or coordinate arithmetic.

## Output files

Each lane has its own packed `.bin` file. `metadata.json` gives the exact logical
bit count, padding, interpretation and SHA-256 of each file.

| File | Meaning of each logical bit |
|---|---|
| `grammar.bin` | Original instruction/opcode |
| `phase.bin` | Opcode XOR orientation after this event's seam |
| `step.bin` | Step/time-advance request: opcode XOR 1 |
| `turn.bin` | Symbolic turn/branch request: opcode |
| `seams.bin` | Explicit external seam event, not automatically detected |
| `orientation.bin` | Current seam parity |

These are separate **one-bit lanes**, not channels of a six-bit amplitude
sample. Keeping all six is useful for inspection but costs six times the
single-lane payload storage. For the default run each lane is **8,192 bytes**
for **65,536 logical bits**. Transport only the lane(s) your application needs.

The low-order bits of a partial final byte are zero padding, not extra
instructions or samples. A raw file is not self-framing without its bit count.
Neither extension `.bin` nor the grammar makes the result PCM, a DSD file,
a delta-sigma encoded audio signal, or a timed DAC protocol.

## Import the binary API

```python
from engine import Kernel, iter_word, pack_bits, run

# No float or fixed-point coordinate is created.
word = iter_word(24, count=65536)
payload = pack_bits(event.output for event in run(word))
assert payload.bit_count == 65536
assert len(payload.data) == 8192

# One binary opcode, with an explicit binary seam event.
kernel = Kernel()
event = kernel.step(opcode=0, seam=1)
assert event.step == 1
assert event.turn == 0
assert event.orientation == 1
assert event.output == 1
```

For an explicit seam demonstration:

```sh
python -m engine --depth 12 --full --seam-at 20 --seam-at 100 \
  --output seam_demo
```

Those are zero-based, caller-chosen seam indices, not discovered physical
crossings. Seam events invert the output phase lane, **not** the opcode or its
step/turn interpretation. No numerical SDF is evaluated to locate a seam.

## Serial cell and validation

`RewriteStage` in Python and `tk1_stage` in C implement the same serial rewrite
cell. A valid/ready transfer moves one bit. Backpressure holds the bit and its
end-of-word flag stable. Cascading cells corresponds to repeated grammar
rewriting. This delivery includes a software cycle model and C implementation;
it does not include FPGA synthesis results, a hardware-timed implementation,
or a transducer interface.

The release record reports **71 passing tests, zero failures, zero errors and
zero skips** in the delivery environment. These include exact grammar order,
packing/padding, budget and input validation, seam/XOR semantics, stalled serial
cells, multi-stage software cascades, all 512 four-bit-state/five-bit-input
combinations across Python and C, native payload equality and source audits.
See `validation/VALIDATION.json` and the actual test log.

To produce a new validation record without modifying the delivered one:

```sh
python tools/validate.py --output validation_local
```

Native tests are explicitly skipped when no C compiler is available; the
record distinguishes skipped tests from passed tests. Hardware timing, analog
reconstruction, acoustic focusing, energy recirculation, alias suppression,
and the physical claims of the corpus are not established by these tests.
Do not treat a generated bit file as instructions for driving a power stage.

## Package map

`engine/` — binary reference and CLI. `c/` — native kernel and executable
examples. `tests/` — software and cross-language verification. `examples/` —
packed reference runs. `KERNEL_SPEC.md` — exact execution and framing contract.
`MIGRATION.md` — changes from the earlier kernel. `docs/SOURCE_MAP.md` — source
versus implementation choices. `PROVENANCE.json` — hashes of the source uploads
and previous delivery. `SHA256SUMS.json` — package integrity manifest.

The original PDF, dialogue exports, earlier floating-point code and personal
identifier/date are not copied into this kernel-only archive. Corpus attribution
to Tom Klootwijk is retained; see `LICENSE_NOTE.md` for the attribution boundary.

# Source map and implementation boundaries

The basis is the two originally supplied files, `Tone.pdf` and
`Pasted markdown(9).md`, plus the preceding kernel as the revision target.
Their exact SHA-256 values appear in `PROVENANCE.json`. Originals remain in the
previous corpus package and are not duplicated here.

| Item | Source location | Treatment in B1 |
|---|---|---|
| Abandon floats; use binary encoded words | Tone.pdf, p.21, “The 1-Bit L-System Alphabet” | No numerical amplitude/coordinate path |
| 0 means step/propagation, 1 means branch/rotation | Tone.pdf, p.21; Markdown section IV, alphabet | Decoded as separate one-bit request lanes; no unspecified metric action invented |
| Grammar replaces the coordinate-search tree | Tone.pdf, p.22, “Replacing the Binary Search Tree with Grammar”; Markdown section IV | Finite production expansion, not coordinate search |
| Production 0 -> 1 and 1 -> 01 | Tone.pdf, p.22; Markdown section IV, production rules | Implemented exactly |
| Word as coordinate description | Tone.pdf, pp.21–22; Markdown section IV | Retained as symbolic path; no assertion that length alone computes metric distance |
| Phase inversion associated with wrapping | Tone.pdf, pp.21–22; Markdown section III | Explicit external seam bit, one-bit parity state; geometric crossing not inferred |
| Do not convert terminal words back to floats | Tone.pdf, p.22, final output discussion; Markdown section V | Direct binary output, no float quantizer or PCM adapter |
| Smooth minimum and geometrical field blending | Tone.pdf, p.14; Markdown section III | No scalar evaluation in B1; not equated with XOR |

The binary grammar can be implemented exactly from the supplied productions.
A unique numerical distance oracle, seam detector, branching geometry, clock,
modulation/reconstruction chain or device protocol cannot be extracted from
those productions alone. Those source-level ideas are not silently presented
as completed modules.

New engineering choices in this delivery: default seed 0; maximum depth 512;
finite-generation/prefix validation; 1,000,000 default event budget; packed
MSB-first storage; separate bit-count metadata; pre-output seam parity update;
output XOR; one-bit request lanes; four-flag serial cell; explicit ready/valid
and last flags; compiled C reference and verification suite.

No physical claims about focusing, zero aliasing, energy recirculation, waveform
purity or noise shaping are inferred from test success. This distinction does
not modify the source text; it defines what the delivered code actually does.

# Delivered binary examples

`generation_12/` is the full 233-bit seed-0 generation 12 with no seams. Each lane
is 30 bytes, with 7 unused low padding bits in the final byte. Raw grammar and
phase output are identical. These are bit files, not a 16-bit reference WAV.

`prefix_65536/` is exactly 65,536 bits from generation 24. Each lane is 8,192
bytes with no padding. The full generation would contain 75,025 bits; the
sidecar explicitly identifies this as a prefix of a finite generation.

`explicit_seams/` is generation 12 with caller-specified seams at zero-based
indices 20 and 100. It demonstrates the parity/XOR rule. The seam positions
are not computed from geometry or measured from hardware.

Each directory has `metadata.json` with the logical bit count, packing rule,
stream meaning, payload hash and control parameters. The six files are six
independent one-bit lanes, not one six-bit-amplitude channel. Transporting only
`phase.bin` or `grammar.bin` costs one logical bit per event.

Regenerate in new directories from the package root:

```sh
python -m engine --depth 12 --full --output regenerated_12
python -m engine --depth 24 --count 65536 --output regenerated_prefix
python -m engine --depth 12 --full --seam-at 20 --seam-at 100 --output regenerated_seams
```

No sample rate, device voltage, acoustic pressure, calibrated waveform, or
reconstruction filter is assigned to these files. Do not treat the raw grammar
stream as an audio coding standard or a power-stage drive protocol.

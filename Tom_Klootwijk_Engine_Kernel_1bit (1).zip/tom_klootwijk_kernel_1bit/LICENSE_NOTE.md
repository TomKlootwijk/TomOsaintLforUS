# Attribution and licensing note

Corpus attribution: **Tom Klootwijk**, as supplied in this conversation.

This B1 implementation and its tests/documentation were generated as a new
adaptation for the requested one-bit kernel. They are not recovered original
author code and are not unchanged copies of the earlier numerical kernel.
No third-party source implementation or dependency package is bundled.

The package does not independently verify authorship, identity, registration,
ownership, novelty, or physical performance. No open-source license has been
selected for the user's corpus/project in this delivery; no license is asserted
over the original uploads. Package hashes provide reproducible byte-level
references, not identity verification or a trusted timestamp.

Only the supplied name is repeated for attribution. The supplied personal
identifier and date are unnecessary for the executable and are not copied into
this archive. Review project licensing and attribution before redistribution.

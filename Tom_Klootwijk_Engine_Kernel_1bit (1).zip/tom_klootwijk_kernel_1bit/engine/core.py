"""B1: binary-symbol execution, not floating-point DSP followed by quantization.

Data values are bits (integers exactly 0 or 1). Integers used for lengths,
expansion depth, byte indexing and emission budgets are control metadata.
No numerical coordinate, amplitude, fixed-point or floating-point path exists.
"""
from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from typing import BinaryIO

MAX_DEPTH = 512
DEFAULT_BUDGET = 1_000_000


def _uint(value: int, name: str, maximum: int | None = None) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    if maximum is not None and value > maximum:
        raise ValueError(f"{name} must not exceed {maximum}")
    return value


def bit(value: int, name: str = "bit") -> int:
    """Accept exactly integer 0 or 1; do not coerce an amplitude to a bit."""
    return _uint(value, name, 1)


def symbol_counts(depth: int, seed: int = 0) -> tuple[int, int]:
    """Exact zero/one counts; arithmetic here describes lengths, not samples."""
    _uint(depth, "depth", MAX_DEPTH)
    bit(seed, "seed")
    zeros, ones = 1 ^ seed, seed
    for _ in range(depth):
        zeros, ones = ones, zeros + ones
    return zeros, ones


class _BitStack:
    """Packed pending symbols. Expansion depths live in a separate control stack."""
    __slots__ = ("_bytes", "_count")

    def __init__(self) -> None:
        self._bytes = bytearray()
        self._count = 0

    def push(self, value: int) -> None:
        offset = self._count & 7
        if offset == 0:
            self._bytes.append(0)
        self._bytes[-1] |= value << (7 - offset)
        self._count += 1

    def pop(self) -> int:
        if self._count == 0:
            raise IndexError("empty bit stack")
        self._count -= 1
        offset = self._count & 7
        value = (self._bytes[-1] >> (7 - offset)) & 1
        if offset == 0:
            self._bytes.pop()
        else:
            self._bytes[-1] &= ~(1 << (7 - offset))
        return value


def iter_word(depth: int, seed: int = 0, *, count: int | None = None,
              budget: int = DEFAULT_BUDGET) -> Iterator[int]:
    """Emit a finite generation, or exactly `count` bits of that generation.

    Productions: 0 -> 1; 1 -> 01. A requested prefix is not an infinite fixed
    word: the first bit can change between generations. No word is prebuilt.
    Symbol stack storage is packed; depth/index metadata is multi-bit.
    """
    zeros, ones = symbol_counts(depth, seed)
    _uint(budget, "budget")
    total = zeros + ones
    wanted = total if count is None else _uint(count, "count")
    if wanted > total:
        raise ValueError("count exceeds this finite generation's length")
    if wanted > budget:
        raise ValueError("emission exceeds budget; request a prefix or raise budget")
    if wanted == 0:
        return
    symbols = _BitStack()
    symbols.push(seed)
    levels = [depth]
    emitted = 0
    while levels and emitted < wanted:
        level = levels.pop()
        symbol = symbols.pop()
        if level == 0:
            yield symbol
            emitted += 1
        elif symbol == 0:
            symbols.push(1)
            levels.append(level - 1)
        else:
            # LIFO: the right child is pushed before the left child.
            symbols.push(1)
            levels.append(level - 1)
            symbols.push(0)
            levels.append(level - 1)


def rewrite_once(symbols: Iterable[int]) -> Iterator[int]:
    """One streaming parallel-rewrite generation, preserving child order."""
    for symbol in symbols:
        if bit(symbol) == 1:
            yield 0
        yield 1


@dataclass(frozen=True, slots=True)
class PackedBits:
    """Canonical MSB-first payload: eight logical symbols per full byte."""
    data: bytes
    bit_count: int

    def __post_init__(self) -> None:
        if type(self.data) is not bytes:
            raise ValueError("data must be immutable bytes")
        _uint(self.bit_count, "bit_count")
        if len(self.data) != (self.bit_count + 7) // 8:
            raise ValueError("payload length does not match logical bit count")
        remainder = self.bit_count & 7
        if remainder and self.data[-1] & ((1 << (8 - remainder)) - 1):
            raise ValueError("unused low-order padding bits must be zero")

    def __iter__(self) -> Iterator[int]:
        for index in range(self.bit_count):
            yield (self.data[index >> 3] >> (7 - (index & 7))) & 1


def pack_bits(symbols: Iterable[int]) -> PackedBits:
    buffer = bytearray()
    count = 0
    for symbol in symbols:
        value = bit(symbol)
        if (count & 7) == 0:
            buffer.append(0)
        buffer[-1] |= value << (7 - (count & 7))
        count += 1
    return PackedBits(bytes(buffer), count)


def unpack_bits(data: bytes, bit_count: int) -> Iterator[int]:
    return iter(PackedBits(data, bit_count))


class BitWriter:
    """Bounded-buffer binary writer; deliberately provides no PCM/WAV output.

    Uses blocking binary streams. `finish()` pads the last byte with zeros,
    returns the logical count, and leaves the underlying stream open.
    """
    __slots__ = ("_stream", "_buffer", "_byte", "_used", "count", "_done")

    def __init__(self, stream: BinaryIO) -> None:
        self._stream = stream
        self._buffer = bytearray()
        self._byte = 0
        self._used = 0
        self.count = 0
        self._done = False

    def _flush(self) -> None:
        data = bytes(self._buffer)
        offset = 0
        while offset < len(data):
            written = self._stream.write(data[offset:])
            if written is None or written <= 0 or written > len(data) - offset:
                raise OSError("binary stream did not accept the pending bytes")
            offset += written
        self._buffer.clear()

    def write(self, value: int) -> None:
        if self._done:
            raise ValueError("writer is already finished")
        self._byte |= bit(value) << (7 - self._used)
        self._used += 1
        self.count += 1
        if self._used == 8:
            self._buffer.append(self._byte)
            self._byte = 0
            self._used = 0
            if len(self._buffer) >= 4096:
                self._flush()

    def finish(self) -> int:
        if not self._done:
            if self._used:
                self._buffer.append(self._byte)
            self._flush()
            self._done = True
        return self.count


def write_bits(stream: BinaryIO, symbols: Iterable[int]) -> int:
    writer = BitWriter(stream)
    for value in symbols:
        writer.write(value)
    return writer.finish()


@dataclass(frozen=True, slots=True)
class BitEvent:
    """Six independent one-bit lanes, not one six-bit amplitude sample."""
    opcode: int
    step: int
    turn: int
    seam: int
    orientation: int
    output: int


class Kernel:
    """Symbolic interpreter with one persistent orientation bit.

    `step` and `turn` are application events, not numerical geometry. Seam
    crossing is explicitly supplied, never guessed from a depth or counter.
    """
    __slots__ = ("_orientation",)

    def __init__(self, orientation: int = 0) -> None:
        self._orientation = bit(orientation, "orientation")

    @property
    def orientation(self) -> int:
        return self._orientation

    def reset(self, orientation: int = 0) -> None:
        self._orientation = bit(orientation, "orientation")

    def step(self, opcode: int, seam: int = 0) -> BitEvent:
        opcode = bit(opcode, "opcode")
        seam = bit(seam, "seam")
        self._orientation ^= seam  # This event's seam is applied before output.
        return BitEvent(opcode, opcode ^ 1, opcode, seam,
                        self._orientation, opcode ^ self._orientation)


def run(symbols: Iterable[int], seams: Iterable[int] | None = None, *,
        orientation: int = 0) -> Iterator[BitEvent]:
    """Match one optional seam bit to each opcode; mismatched lengths are errors."""
    kernel = Kernel(orientation)
    seam_source = None if seams is None else iter(seams)
    for opcode in symbols:
        if seam_source is None:
            seam = 0
        else:
            try:
                seam = next(seam_source)
            except StopIteration as exc:
                raise ValueError("seam stream is shorter than opcode stream") from exc
        yield kernel.step(opcode, seam)
    if seam_source is not None:
        try:
            next(seam_source)
        except StopIteration:
            return
        raise ValueError("seam stream is longer than opcode stream")


@dataclass(frozen=True, slots=True)
class StageSignals:
    in_ready: int
    out_valid: int
    out_bit: int
    out_last: int


class RewriteStage:
    """Cycle model of a one-bit serial rewrite cell (also supplied as C/RTL).

    Persistent state is four Boolean flags: busy, data, tail and last.
    tick() returns PRE-edge signals and then applies that edge. A transfer
    occurs only with ready & valid. There is intentionally an input bubble
    while a symbol is being expanded; no constant sample rate is promised.
    """
    __slots__ = ("busy", "data", "tail", "last")

    def __init__(self) -> None:
        self.busy = self.data = self.tail = self.last = 0

    def signals(self, reset: int = 0) -> StageSignals:
        reset = bit(reset, "reset")
        return StageSignals((self.busy ^ 1) & (reset ^ 1),
                            self.busy & (reset ^ 1),
                            self.data, self.last & (self.tail ^ 1))

    def tick(self, in_valid: int = 0, in_bit: int = 0, in_last: int = 0,
             out_ready: int = 0, reset: int = 0) -> StageSignals:
        for name, value in (("in_valid", in_valid), ("in_bit", in_bit),
                            ("in_last", in_last), ("out_ready", out_ready),
                            ("reset", reset)):
            bit(value, name)
        signals = self.signals(reset)
        if reset:
            self.busy = self.data = self.tail = self.last = 0
        elif self.busy:
            if out_ready:
                if self.tail:
                    self.data, self.tail = 1, 0
                else:
                    self.busy = 0
        elif in_valid:
            self.busy = 1
            self.data = in_bit ^ 1
            self.tail = in_bit
            self.last = in_last
        return signals

"""Write packed bit-lanes and explicit framing metadata. No audio playback."""
from __future__ import annotations
import argparse
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path

from . import __version__
from .core import (DEFAULT_BUDGET, MAX_DEPTH, BitWriter, Kernel, iter_word,
                   symbol_counts)


def generate(output: Path, *, depth: int = 24, seed: int = 0,
             count: int | None = 65536, budget: int = DEFAULT_BUDGET,
             seam_at: tuple[int, ...] = (), orientation: int = 0) -> dict:
    # iter_word validation is intentionally forced before files are created.
    source = iter_word(depth, seed, count=count, budget=budget)
    sentinel = object()
    first = next(source, sentinel)
    zero_total, one_total = symbol_counts(depth, seed)
    wanted = zero_total + one_total if count is None else count
    if any(type(n) is not int or n < 0 or n >= wanted for n in seam_at):
        raise ValueError("every seam index must be within the emitted prefix")
    if len(set(seam_at)) != len(seam_at):
        raise ValueError("duplicate seam indices are not allowed")
    kernel = Kernel(orientation)
    indices = set(seam_at)
    output = Path(output)
    filenames = ["grammar.bin", "phase.bin", "step.bin", "turn.bin",
                 "seams.bin", "orientation.bin", "metadata.json"]
    if output.exists() and (not output.is_dir() or any((output / n).exists() for n in filenames)):
        raise ValueError("output already contains generated files; choose a new directory")
    output.mkdir(parents=True, exist_ok=True)
    counts = {"zeros": 0, "ones": 0, "output_ones": 0}
    lane_names = ("grammar", "phase", "step", "turn", "seams", "orientation")
    with ExitStack() as stack:
        writers = {name: BitWriter(stack.enter_context((output / (name + ".bin")).open("wb")))
                   for name in lane_names}
        def all_symbols():
            if first is not sentinel:
                yield first
            yield from source
        for index, opcode in enumerate(all_symbols()):
            event = kernel.step(opcode, int(index in indices))
            values = (event.opcode, event.output, event.step, event.turn,
                      event.seam, event.orientation)
            for name, value in zip(lane_names, values):
                writers[name].write(value)
            counts["ones" if opcode else "zeros"] += 1
            counts["output_ones"] += event.output
        for writer in writers.values():
            if writer.finish() != wanted:
                raise RuntimeError("internal emission count mismatch")
    meanings = {
        "grammar": "opcode: 0=step event, 1=turn/branch request",
        "phase": "opcode XOR orientation after this event's seam",
        "step": "one-bit step/time-advance request; complement of opcode",
        "turn": "one-bit symbolic turn/branch request; same bit as opcode",
        "seams": "caller-supplied seam events; demonstration indices, not geometric detection",
        "orientation": "one-bit parity of seam events, including initial orientation",
    }
    streams = {}
    for name in lane_names:
        path = output / (name + ".bin")
        streams[name] = {"file": path.name, "logical_bits": wanted,
                         "storage_bytes": path.stat().st_size,
                         "padding_bits": (8 - (wanted & 7)) & 7,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                         "meaning": meanings[name]}
    metadata = {
        "format": "TK-B1-RAW/1", "version": __version__, "profile": "B1",
        "packing": "MSB-first; unused low-order bits of final byte are zero",
        "depth": depth, "seed": seed, "requested_count": count,
        "full_generation_bits": zero_total + one_total,
        "emitted_bits": wanted, "is_prefix": wanted < zero_total + one_total,
        "initial_orientation": orientation, "seam_indices": sorted(indices),
        "counts": counts, "streams": streams,
        "clock": "unspecified; logical order only, no sample-rate promise",
        "not_pcm": True, "not_sigma_delta_encoded_audio": True,
        "floating_point_signal_path": False,
        "fixed_point_coordinate_path": False,
        "seam_detection": "external; no metric manifold oracle is implemented",
    }
    (output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("run_output"))
    parser.add_argument("--depth", type=int, default=24, help=f"finite generation 0..{MAX_DEPTH}")
    parser.add_argument("--seed", type=int, choices=(0, 1), default=0)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--count", type=int, default=None, help="exact prefix length")
    group.add_argument("--full", action="store_true", help="emit the entire finite generation")
    parser.add_argument("--budget", type=int, default=DEFAULT_BUDGET)
    parser.add_argument("--seam-at", type=int, action="append", default=[],
                        help="zero-based external seam event; may be repeated at distinct indices")
    parser.add_argument("--orientation", type=int, choices=(0, 1), default=0)
    args = parser.parse_args(argv)
    count = None if args.full else (65536 if args.count is None else args.count)
    try:
        result = generate(args.output, depth=args.depth, seed=args.seed,
                          count=count, budget=args.budget,
                          seam_at=tuple(args.seam_at), orientation=args.orientation)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(f"Wrote {result['emitted_bits']} logical bits per lane to {args.output}")
    print("Binary grammar/phase events only: no floats, PCM, playback or hardware driver.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

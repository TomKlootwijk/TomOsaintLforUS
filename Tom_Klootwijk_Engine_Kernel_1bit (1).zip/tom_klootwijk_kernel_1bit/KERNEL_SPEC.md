# B1 — executable one-bit kernel contract

Version 0.2.0. This is an explicit binary symbolic implementation profile. It
supersedes the former P0 numerical implementation; it is not a claim that every
physical mechanism described in the corpus has been implemented.

## 1. Source-defined grammar

Alphabet B = {0,1}. Production h(0) = 1 and h(1) = 01. For a chosen seed b,
finite generation d is h applied d times to b. Rewriting is simultaneous and
preserves the order of the children. Default seed b=0 is a profile choice, not
a uniquely specified source requirement.

```text
depth   seed-0 word
0       0
1       1
2       01
3       101
4       01101
5       10101101
6       0110110101101
```

Counts satisfy (z_next, o_next) = (o, z+o), initially (1,0) for seed 0 and
(0,1) for seed 1. This integer arithmetic counts symbols; it does not represent
an amplitude or a coordinate. The Fibonacci structure is retained without
numerically evaluating a golden-ratio constant or a turn angle.

The API emits a particular finite generation. Adjacent generations need not
share a first bit. Do not concatenate, truncate or repeat generations under an
unstated assumption that they are one fixed infinite stream.

Depth is limited to 512. `count=None` selects the full finite generation;
otherwise count is an exact nonnegative prefix length and must not exceed the
full length. The Python default emission budget is 1,000,000 bits; explicitly
raise the budget to permit a longer run. The native demo caps its count at
1,000,000. The native library emits until the finite generation ends or its
caller stops requesting bits.

Software expansion uses depth-first traversal only to enumerate the ordered
production outputs. It is **not** the earlier coordinate-search BST. Pending
symbols are packed in a bit stack. Depths are a separate integer control stack.
The unexpanded future word is not materialized. At most d+1 pending symbols and
d+1 depth entries are needed. A materialized output still costs storage
proportional to its logical length, even though generation is streaming.

## 2. Binary instruction and orientation lanes

For each event n, inputs are an opcode b[n] and an explicit seam bit s[n]. The
only persistent interpreter state is orientation o in B. Initial o is 0 by
default. All formulas in this section are Boolean, not scalar field arithmetic.

```text
o_next[n] = o[n] XOR s[n]
step[n]   = b[n] XOR 1
turn[n]   = b[n]
y[n]      = b[n] XOR o_next[n]
o[n+1]    = o_next[n]
```

A zero opcode requests a step/time advance. The one-bit step lane therefore
forms unary grammar-time events, not a numerical time value. A one opcode
requests the source's turn/branch action symbolically. B1 does not select an
angle, create a geometric branch object, or compute a manifold displacement.
The terminal instruction word remains the symbolic path description.

A seam bit toggles orientation before the current output. Two seams restore
the previous orientation. No seam leaves orientation unchanged. XOR acts on
the emitted phase lane only; it does not change which instruction executes.
The source mentions phase inversion, but this exact update ordering and its
mapping to output bits are introduced B1 interface choices.

The caller must supply the seam event. No coordinate, signed distance,
Klein-bottle embedding, physical boundary detector, or automatic wrap rule is
hidden inside this operation. Without a complete mapping from symbolic paths
to geometric boundary crossings, treating a particular instruction count as
a detected seam would be an additional unsupported assumption.

`run(symbols, seams)` requires one seam bit per opcode when a seam iterable is
supplied. A shorter or longer seam stream raises an error. Invalid bit inputs
are rejected rather than rounded, clipped, coerced from floats, or quantized.
The Python bit API accepts exactly integer 0 and integer 1, not Boolean objects
or other numeric types. The C boundary accepts unsigned values 0 or 1 only.

## 3. Serial rewrite cell

The software cycle model and C serial cell have four persistent Boolean flags:
`busy`, `data`, `tail`, `last`. No multi-bit sample state or numeric generation
counter exists inside an individual cell.

Pre-edge ports, when reset is not asserted:

```text
in_ready = NOT busy
out_valid = busy
out_bit = data
out_last = last AND NOT tail
```

On an idle cell accepting input b with end-of-word flag L:

```text
busy <- 1
data <- NOT b
tail <- b
last <- L
```

Thus input 0 queues only 1. Input 1 queues 0 and marks a remaining 1. On an
output transfer, a pending tail changes `data` to 1 and clears `tail`; otherwise
`busy` clears. Input is not accepted while busy, including the edge releasing
the last output bit. This intentional bubble simplifies the protocol. Under
backpressure the queued output bit and last flag remain unchanged.

Reset synchronously clears all four flags; in_ready and out_valid are masked
while reset is asserted. `tick` returns the **pre-edge** port values and then
applies the edge. Stale data when out_valid is zero is not a transfer.

Cascade d cells to model d production rewrites. A last flag passes to the last
child, not the first child of `01`, so word/frame boundaries survive rewriting.
The included tests compare software cascades to direct finite-generation
expansion under input/output handshaking and backpressure. No fixed sample
rate is claimed. A stalled or bubbling cell cannot be wired to a fixed-clock
DAC without a separately designed timing/transport layer.

## 4. Canonical packed format TK-B1-RAW/1

Raw `.bin` payloads have no header. The sidecar metadata supplies the logical
bit count N and the lane interpretation. The first logical bit occupies bit 7
of byte 0, the second bit 6, and so on. Byte length is (N+7)//8. Empty streams
have no payload bytes. When N is not byte-aligned, unused low-order bits of
the final byte are zero. Padding bits are not events.

Example: logical `101100101` has N=9 and bytes `B2 80`. Six separate one-bit
lanes in a demonstration are not a six-bit PCM sample or six amplitude bits.
Transporting only the phase lane uses exactly one logical bit per event.

`PackedBits` requires canonical length and zero padding. Python `BitWriter`
flushes bounded byte buffers and leaves its underlying blocking stream open.
It handles short positive writes and reports failed writes. The raw grammar,
phase output and seam flags have distinct semantics despite the same packing.
Neither binary encoding nor an opcode's numeric value assigns a physical
pressure, voltage, frequency, or sound level. A bit value 0 is not a claim of
acoustic silence.

## 5. Width boundary and excluded numerical path

Data alphabet, per-event lanes and logical interpreter/cell flags are one-bit.
The C implementation packs pending grammar symbols and uses one-bit bitfields
for Boolean state. Its host storage allocation is not literally one bit per C
object. The Python interpreter likewise stores Boolean-valued host integers;
it is a readable reference model, not a one-bit processor emulator.

Control indexes, recursion/expansion depths, counts, capacities, byte I/O,
protocol validity, and filesystem metadata are not amplitude samples. They
may use ordinary host widths. There are no floating-point or fixed-point
coordinate calculations and no multi-bit amplitude DSP followed by a final
one-bit quantizer in B1.

The P0 pitch/log-polar helpers, trigonometric motion, numerical Klein chart,
scalar SDF helpers, polynomial smin evaluation, float sigma-delta loop and
16-bit WAV generation are absent. A scalar smooth-min function is not
silently identified with XOR. The golden-ratio rotation, metric distance,
log-polar indexing and geometric branch implementation require an additional
specified binary mapping before they can be implemented with matching semantics.

## 6. Validation boundary

Software evidence: source grammar order, finite-generation and prefix rules,
packing, Boolean invariants, explicit seam behavior, cycle-level handshaking,
C/Python equality and compiled native C tests. A separate sanitizer run is
recorded if executed in the delivered environment.

Not established: hardware synthesis, cycle timing on a target device, physical
propagation, geometrical distance recovery from word depth, anti-aliasing,
quantization-noise shaping, acoustic beam invariance, energy recovery, analog
reconstruction, or amplifier/transducer suitability. The source's broader
claims are not converted into software guarantees by this implementation.
